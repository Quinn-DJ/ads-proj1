# 任务 1–3 实测结果（本轮重新构建基线）

> **运行日期 2026-10-20**；本轮重新构建基线；**所有命令均由本轮运行产生**；日志在
> `reports/data/logs/tasks/`，图/表 CSV 在 `reports/data/csv/tasks/`，临时索引与脚本在
> `reports/data/work/tasks/`。本文件不含任何从 README/notes/plan/旧报告抄来的数字；与旧文档
> 数值相同处均为本轮重新测量的结果。
>
> **环境**：macOS 27.0.1 (build 26A434) / Apple M3 / cmake 4.4.3 / Apple clang 21.0.0
> （目标 arm64-apple-darwin27.0.0）。本轮配置：`cmake -S . -B build -DCMAKE_BUILD_TYPE=Release`
> （`build/CMakeCache.txt` 实测 `CMAKE_BUILD_TYPE:STRING=Release`、`CMAKE_CXX_FLAGS_RELEASE:STRING=-O3 -DNDEBUG`、
> `CMAKE_GENERATOR:INTERNAL=Unix Makefiles`）；C++17（`CMAKE_CXX_EXTENSIONS OFF` → `-std=c++17`）+ `-Wall -Wextra`。
> 二进制 `build/mse` = 329,136 B，mtime 2026-10-20 12:48（与 CMakeCache 同一分钟，本轮新配置/编译）。
>
> **计时口径**：每次实验独立进程；外部耗时用 `python3 time.time()` 包住子进程（含进程启动/文件加载），
> 3 次取**中位数**；同时记录 C++ 内建 `build time`。测量时另一位 analyst 正在并行跑验证任务，
> 机器存在并行负载，绝对耗时约有 ±20% 波动，**只宜作量级/相对比较**，不要写成精确基准。
> 所有计时均为本轮串行执行（同一时刻只有一条计时命令在跑）。

## 关键事实速查

| 主题 | 关键读数 | 事实号 |
|---|---|---|
| 主语料规模 | 195 文档 / 152,632 行 / 930,911 words / 4,919,371 B；正文 token 866,626 | F1 |
| 语料构成 | sonnet 154 + play 37 + poem 4；Poetry 158 / Comedy 17 / History 10 / Tragedy 10 | F3 |
| 第二语料 RFC | 3 文档 / 9,946 行 / 81,848 words / 569,472 B；token 75,250，distinct 4,328 | F2、F3 |
| 静态停用词表 | 39 词（由本语料统计推导） | F4 |
| 词频默认 | 866,626 token；25,705 distinct；9,753 hapax（占 distinct 37.94%） | F6 |
| 去停用词 | 556,866 token（removed 309,760 = 35.74%）；25,666 distinct | F6 |
| 词干化 | 866,626 token；14,947 distinct（-41.85% 词形）；hapax 4,843 | F6 |
| 词干+停用词 | 556,866 token；14,937 distinct；hapax 4,846 | F6 |
| 停用词候选带 | 9 词 = the and i to of my that in but（占全部 token 17.87%） | F10 |
| 推导规则扫描 | (0.75,0.93)→9 词 / (0.50,0.95)→23 / (0.40,0.93)→39（与静态表重叠 35）/ (0.30,0.93)→50 | F13、F14 |
| 4 种索引 | raw 5,598,793 B（25,705 词）；stop 4,320,622 B（25,666）；stem 4,958,598 B（14,947）；正式 3,685,655 B（14,937） | F18 |
| 三词典 | splay 6,392,724 比较/5,850,795 旋转；hash 688,494 比较/11 rehash；map 9,435,694 比较；三者产物**逐字节相同** | F20 |
| v2 压缩 | 3,685,655 → 1,725,694 B（**46.82%**，省 1,959,961 B = 53.18%） | F21 |
| 块式构建 | 17 块 / 峰值 5,129 活词 / run 4,166,556 B（临时）；与内存构建**逐字节相同** | F22 |
| B+Tree sidecar | 237,568 B（v1 的 6.45%）；dump banquo 冷查询 2 页读、索引读 8,308 B（全载的 0.225%）；verify-all 14,937 词 0 差异 | F23 |
| 查询 | osric 1 篇；love 138 篇；"king richard" 7 篇→top-x3；"my lord" 停用词退化 42 篇；loves→love 138 篇（raw 上 loves 43 篇） | F28–F34 |
| 阈值矩阵 | 201 条测量（+表头=202 行），15 查询 × 4 参数；单查询约 19.2 ms（中位，含进程启动） | F36、F38 |
| CLI | 9 个子命令；shell/selftest 未实现（rc=2） | F40 |

---

## A. 语料与环境基线

### F1 主语料 `mse stats`（manifest = data/manifest.tsv）

| 指标 | 值 |
|---|---|
| documents | 195 |
| lines 总计 | 152,632 |
| — body | 114,315 |
| — heading | 1,099 |
| — stage | 6,251 |
| — speaker | 30,967 |
| words | 930,911 |
| bytes | 4,919,371 |
| documents by category | Comedy 17 / History 10 / Poetry 158 / Tragedy 10 |

命令：`./build/mse stats`。日志：`reports/data/logs/tasks/corpus-stats.log`。
口径：`words` 为文本层按空白切分的原始词数（未过滤行标记）；`lines` 按行首标记分类，
`body` 即参与默认切词的行。

### F2 第二语料 RFC `mse stats`

| 指标 | 值 |
|---|---|
| documents | 3（rfc1035/5321/7231） |
| lines / body | 9,946 / 9,946（无 heading/stage/speaker） |
| words | 81,848 |
| bytes | 569,472 |
| documents by category | IETF 3 |

命令：`./build/mse stats --manifest data2/data/manifest.tsv`。日志：`reports/data/logs/tasks/corpus-stats.log`。
另测 `mse count --manifest data2/data/manifest.tsv`：token 75,250 / distinct 4,328 / hapax 1,506；
日志 `reports/data/logs/tasks/rfc-count-and-aggregates.log`。

### F3 manifest 构成、文本层与原始语料规模

`reports/data/work/tasks/analyze_manifest.py`（保留可复现）实测：

| manifest | documents | kind | category | format |
|---|---|---|---|---|
| `data/manifest.tsv` | 195 | sonnet 154 / play 37 / poem 4 | Poetry 158 / Comedy 17 / History 10 / Tragedy 10 | 缺省 marked |
| `data2/data/manifest.tsv` | 3 | rfc 3 | IETF 3 | plain 3 |

- 文档表 docid 1..195 无重复、无缺号；195 个 `data/text/*.txt` 全部存在（脚本按 manifest 根目录解析）。
- `data/text` 文件数：**195**（`ls data/text/*.txt | wc -l`）。
- `data/raw`：**递归 1,211 个 `.html`**（`find data/raw -name '*.html' | wc -l`），共 1,225 个文件、41 个子目录，`du -sh` = **25M**；`ls data/raw/*.html` 只匹配到 6 个顶层文件（index/works/news/test 等入口页）——统计整个镜像必须用递归方式。
- `data/raw/SOURCE.txt`：仓库 `TheMITTech/shakespeare`、镜像 `shakespeare.mit.edu`、commit `6b82db852c7322dd33e95db347f0ddfc812c6409`（2019-01-20 "Fix typo in Hamlet"）、fetched 2026-10-10、`html files: 1211`。
- `data2/raw/SOURCE.txt`：RFC 1035/5321/7231 纯文本，下载于 2026-10-17，含 3 个 sha256；`data2` 目录 580K（raw 与 data 各一份拷贝）。
- `du -sh`：`data/raw` 25M、`data/text` 5.5M、`data2/raw` 580K、`data2/data` 580K。

脚本：`python3 reports/data/work/tasks/analyze_manifest.py`。
日志：`reports/data/logs/tasks/manifest-analysis.log`、`reports/data/logs/tasks/env-corpus-more.log`。
**注意**：`data2/data/manifest.tsv` 的 `text` 列是相对 *语料根* `data2/` 的路径（如 `data/text/0001_rfc1035.txt`），
引擎按 `dirname(dirname(manifestPath))` 解析（src/corpus.cpp:195-202）；脚本若按 cwd 直接 `isfile` 会误报 3 个"缺失"，实际 `mse stats` 正常读入。

### F4 静态停用词表 `data/stopwords.txt`

- 有效词条 **39 个**（`grep -v '^#' data/stopwords.txt | grep -vc '^$'` = 39；文件另有 20 行注释头）。
- 全文（按文件顺序）：
  `the and i to of a my that in is not me it for with be his this but have as so what by no all do if are on from or which more then their when than yet` —— 共 39 词。
- 文件头声明生成方法（本语料统计推导，非外部表）：候选带 `tf_share >= 0.1%` 且 `df_ratio >= 0.40`（48 词），再人工保留结构性功能词 → 39 词；*故意*不收录内容词 love/time 与古体功能词 thou thee thy hath doth o/mine。
- 日志：`reports/data/logs/tasks/stopwords-list.log`。

### F5 环境、构建与代码规模

| 项 | 值 |
|---|---|
| OS | macOS 27.0.1（ProductVersion），Build 26A434 |
| CPU | Apple M3 |
| cmake | 4.4.3 |
| 编译器 | Apple clang 21.0.0（clang-2100.3.34.2），target arm64-apple-darwin27.0.0 |
| 生成器 / 构建类型 | Unix Makefiles / Release |
| Release 编译选项 | `-O3 -DNDEBUG`（CMake 默认 Release；CMakeLists 注释提到的 `-O2` 只是开发约定，以实际 Cache 为准） |
| 语言级别 | C++17，`CMAKE_CXX_EXTENSIONS=OFF`；`-Wall -Wextra` |
| `build/mse` | 329,136 B，mtime 2026-10-20 12:48 |
| 代码规模 | `src/*.cpp` 5,346 行 + `include/*.hpp` 1,103 行 = **6,449 行** |

命令：`sw_vers`、`sysctl -n machdep.cpu.brand_string`、`cmake --version`、`clang++ --version`、
`grep ... build/CMakeCache.txt`、`sed -n '30,75p' CMakeLists.txt`、`wc -l src/*.cpp include/*.hpp`。
日志：`reports/data/logs/tasks/env.log`、`reports/data/logs/tasks/env-corpus-more.log`。
`build/mse` 与 `build/CMakeCache.txt` 时间戳证明二者是同一轮（12:48）生成；旧 `build/` 已不存在，
不存在混用旧产物的问题。

---

## B. 任务 1：词频统计与停用词

### F6 四种 count 配置总表（本轮实测）

命令模板：`./build/mse count --top 50 --csv reports/data/work/tasks/wordcount-<cfg>.csv [--stop-words data/stopwords.txt] [--stem]`；
每种配置独立进程跑 3 次取中位耗时。日志：`reports/data/logs/tasks/count-timings.log`、
各配置摘要 `reports/data/work/tasks/{default,stop,stem,stem_stop}.run1.txt`。

| 配置 | tokens | distinct | hapax(tf=1) | stopped/removed | CSV 字节 | 外部耗时中位（3 次） |
|---|---|---|---|---|---|---|
| 默认（raw token） | 866,626 | 25,705 | 9,753 | — | 1,677,253 | 0.1344 s |
| `--stop-words` | 556,866 | 25,666 | 9,753 | removed 309,760（35.74%） | 1,674,689 | 0.1447 s |
| `--stem` | 866,626 | 14,947 | 4,843 | — | 958,633 | 0.1529 s |
| `--stem --stop-words`（正式） | 556,866 | 14,937 | 4,846 | removed 309,760（35.74%） | 957,871 | 0.1575 s |

口径：`tokens` = 过滤行标记后的正文 token 总数；`distinct` = CSV 行数（不同词/词干个数）；
`hapax` = `tf==1` 的词数；`removed` = 分词表命中剔除的 token 数，百分比分母为 866,626。
3 次逐次耗时见 F16。词干化把 25,705 个词形压成 14,947 个词干（-41.85%），但 token 总数不变。
`--stop-words` 只减少 39 个词形（25,705→25,666），却去掉 35.74% 的 token——停用词是高频词。
词干+停用词的 distinct 比只词干少 10（14,947→14,937），hapax 反而多 3（4,843→4,846）：剔除停用词
后部分词干的 tf 从 2 变 1，属预期交互。

### F7 默认配置 top 10（rank/term/tf/df/df_ratio/tf_share）

来源：`reports/data/csv/tasks/wordcount-default.csv`（本轮默认 CSV 的正式副本，1,677,253 B，
sha256 `6523e3863e54b752a6e53f6baa0b8d4b4b94537b68cec1bffff931a01b25b238`）。

| rank | term | tf | df | df_ratio | tf_share |
|---|---|---|---|---|---|
| 1 | the | 28,436 | 177 | 0.907692 | 0.032812 |
| 2 | and | 25,553 | 189 | 0.969231 | 0.029486 |
| 3 | i | 21,131 | 154 | 0.789744 | 0.024383 |
| 4 | to | 20,302 | 187 | 0.958974 | 0.023426 |
| 5 | of | 16,976 | 175 | 0.897436 | 0.019589 |
| 6 | a | 14,527 | 138 | 0.707692 | 0.016763 |
| 7 | you | 13,998 | 75 | 0.384615 | 0.016152 |
| 8 | my | 12,934 | 159 | 0.815385 | 0.014925 |
| 9 | that | 11,513 | 172 | 0.882051 | 0.013285 |
| 10 | in | 11,479 | 181 | 0.928205 | 0.013246 |

命令：`./build/mse count --top 10`；日志：`reports/data/work/tasks/default.run1.txt`、`reports/data/logs/tasks/count-analysis.log`。

### F8 hapax 与集中度（默认 CSV 的聚合，口径见括号）

| 量 | 值 | 口径 |
|---|---|---|
| hapax / distinct | 37.94% | 9,753 / 25,705 |
| hapax / tokens | 1.125% | 9,753 / 866,626 |
| df==1 的词 | 10,957 | 只在 1 篇文档出现的词形 |
| top10 token 占比 | 20.41% | 176,849 / 866,626 |
| top100 token 占比 | 54.30% | 470,596 / 866,626 |
| top1000 token 占比 | 80.26% | 695,597 / 866,626 |

命令：`python3 reports/data/work/tasks/analyze_count.py`（附聚合脚本，聚合值见
`reports/data/logs/tasks/rfc-count-and-aggregates.log`）。

### F9 报告取词整行（默认 CSV，含熵三列）

取自 `reports/data/csv/tasks/wordcount-default.csv`；`entropy` 为文档分布熵 H（bit），
`entropy_norm = H/log2(df)`，`entropy_rate_norm` 为长度归一化速率熵（满分 1）。

| term | tf | df | df_ratio | tf_share | entropy | entropy_norm | entropy_rate_norm |
|---|---|---|---|---|---|---|---|
| the | 28,436 | 177 | 0.907692 | 0.032812 | 5.409510 | 0.724397 | 0.974758 |
| and | 25,553 | 189 | 0.969231 | 0.029486 | 5.450272 | 0.720722 | 0.978884 |
| i | 21,131 | 154 | 0.789744 | 0.024383 | 5.369447 | 0.738903 | 0.972230 |
| to | 20,302 | 187 | 0.958974 | 0.023426 | 5.463865 | 0.723989 | 0.976542 |
| of | 16,976 | 175 | 0.897436 | 0.019589 | 5.446362 | 0.730936 | 0.974961 |
| a | 14,527 | 138 | 0.707692 | 0.016763 | 5.362329 | 0.754352 | 0.979371 |
| you | 13,998 | 75 | 0.384615 | 0.016152 | 5.212605 | 0.836853 | 0.946379 |
| my | 12,934 | 159 | 0.815385 | 0.014925 | 5.456206 | 0.746109 | 0.961092 |
| love | 2,224 | 127 | 0.651282 | 0.002566 | 5.513827 | 0.788965 | 0.927125 |
| king | 1,368 | 40 | 0.205128 | 0.001579 | 4.353788 | 0.818085 | 0.826028 |
| heart | 1,086 | 70 | 0.358974 | 0.001253 | 5.478672 | 0.893852 | 0.831320 |
| sweet | 852 | 87 | 0.446154 | 0.000983 | 5.397138 | 0.837682 | 0.892507 |
| man | 1,878 | 46 | 0.235897 | 0.002167 | 5.198042 | 0.941067 | 0.938756 |
| wherefore | 142 | 39 | 0.200000 | 0.000164 | 5.100767 | 0.965067 | 0.505023 |
| osric | 3 | 1 | 0.005128 | 0.000003 | 0.000000 | 0.000000 | 0.000000 |
| banquo | 22 | 1 | 0.005128 | 0.000025 | 0.000000 | 0.000000 | 0.000000 |
| thou | 5,777 | 123 | 0.630769 | 0.006666 | 5.479525 | 0.789271 | 0.941290 |
| hath | 2,034 | 78 | 0.400000 | 0.002347 | 5.401749 | 0.859412 | 0.939518 |

（`rank` 列：the 1、and 2、i 3、to 4、of 5、a 6、you 7、my 8、love 62、king 97、heart 110、
sweet 129、man 72、wherefore 638、osric 11,565、banquo 3,028、thou 25、hath 67。）
`osric`/`banquo` 均只出现在 1 篇文档（df=1 → 熵 0），是低 df、高熵特征边界的典型对比样本。
脚本：`reports/data/work/tasks/analyze_count.py`；日志：`reports/data/logs/tasks/count-analysis.log`。

### F10 停用词候选带（默认 CSV 上的三特征规则子集）

- 规则（C++ `stop_candidate` 列）：`df_ratio >= 0.75 && tf_share >= 0.001`。
- 候选 **9 词**：`the and i to of my that in but`；合计 154,887 token，占 866,626 的 **17.87%**。
- 对照：静态表 39 词；`mse count --stop-words` 过滤后候选数变为 0（打印 `stop-candidates … : 0`），
  说明候选带内的词全部来自静态表。

命令：`./build/mse count --top 50`；日志：`reports/data/work/tasks/default.run1.txt`、
`reports/data/logs/tasks/count-analysis.log`。

### F11 候选规则对 df_ratio 阈值的敏感性（固定 tf_share >= 0.001）

方法：对默认 CSV 逐行应用 `df_ratio >= T AND tf_share >= 0.001`，T 从 0.90 递减到 0.40；
"新增"= 相对上一档更严格阈值新增的候选词。脚本：`reports/data/work/tasks/analyze_count.py`
（保留）；日志：`reports/data/logs/tasks/count-analysis.log`。

| T (df_ratio) | 候选数 | 相对上一档新增 | 新增词 |
|---|---|---|---|
| 0.90 | 4 | — | the and to in |
| 0.75 | 9 | +5 | i of my that but |
| 0.70 | 14 | +5 | a is not for with |
| 0.65 | 16 | +2 | so love |
| 0.60 | 21 | +5 | me be thou thy thee |
| 0.50 | 31 | +10 | it this as by all do on from which when |
| 0.40 | 48 | +17 | his have what no if are o or more then their hath than yet mine time doth |

解读：0.75（课程默认）只留 9 个纯功能词；放宽到 0.65 时内容词 `love` 进入候选（这正是静态表
"故意不收录内容词"的动机）；0.40 得到 48 词候选带，即静态表 39 词的人工筛选起点。

### F12 `--keep-speakers` 变体（tokenizer 口径对照）

| 指标 | 默认（过滤 @说话人） | `--keep-speakers` | 差值 |
|---|---|---|---|
| tokens | 866,626 | 906,594 | +39,968（+4.61%） |
| distinct | 25,705 | 25,742 | +37 |
| hapax | 9,753 | 9,722 | -31 |
| CSV 字节 | 1,677,253 | 1,680,023 | +2,770 |

命令：`./build/mse count --keep-speakers --top 5 --csv reports/data/work/tasks/wordcount-keep-speakers.csv`；
日志：`reports/data/logs/tasks/count-timings.log`、`reports/data/work/tasks/keep-speakers.txt`。

### F13 停用词推导扫描（4 组阈值，`--compare data/stopwords.txt`）

命令模板：`./build/mse stopwords --derive --min-df-ratio <r> --min-entropy-rate <h> --out reports/data/work/tasks/stopwords/derived-df<r>-er<h>.txt --compare data/stopwords.txt`
（`--min-tf-share` 保持默认 0.001）。日志：`reports/data/logs/tasks/stopwords-derive.log`。

| 配置 (df_ratio, entropy_rate) | 推导词数 | 与静态表重叠 | only-in-list | only-in-derived | 输出文件 |
|---|---|---|---|---|---|
| (0.75, 0.93) | 9 | 9 | 30 | 0 | `.../stopwords/derived-df0.75-er0.93.txt` |
| (0.50, 0.95) | 23 | 23 | 16 | 0 | `.../stopwords/derived-df0.50-er0.95.txt` |
| (0.40, 0.93) | **39** | **35** | `more or than their` (4) | `hath o thee thou` (4) | `.../stopwords/derived-df0.40-er0.93.txt` |
| (0.30, 0.93) | 50 | 35 | `more or than their` (4) | `at hath he him how let now o thee there thou was well would you` (15) | `.../stopwords/derived-df0.30-er0.93.txt` |

- (0.75,0.93) 的 9 词 = `the and i to of my that in but`，与 F10 的 9 词候选带一致（熵率门槛未再筛掉词）。
- (0.40,0.93) 复现静态表的 39 词带：新推导多出 4 个古体功能词 `hath o thee thou`，静态表多出 4 个
  `more or than their`——差异仅 4 对，可解释为人工审核取舍。
- 4 个输出文件均带出处头（规则/阈值/语料），不含时间戳，重跑逐字节一致；sha256 见
  `reports/data/logs/tasks/stopwords-derived-files.log`（如 39 词版 `ed7d11bf9f2734224e53818d27fa73195c156c129a01a910ccfba225ce34f328`）。

### F14 推导文件内容（(0.40,0.93) 版，39 词）

文件：`reports/data/work/tasks/stopwords/derived-df0.40-er0.93.txt`（464 B）。头注释 6 行 +
正文 39 行，正文按 tf 降序：
`the and i to of a my that in is not me it for with be his this but have as thou so what by no all do if are thee on from o which then when hath yet`。
sha256 `ed7d11bf9f2734224e53818d27fa73195c156c129a01a910ccfba225ce34f328`。
日志：`reports/data/logs/tasks/stopwords-derived-files.log`。

### F15 Python 独立实现对拍（4 种配置逐字节一致）

方法：`python3 tools/check_wordcount.py [--stop-words data/stopwords.txt] [--stem] > <py.csv>`，
再与 C++ `mse count` 产出的 CSV 做 `cmp` 与 sha256 比较。

| 配置 | C++ CSV | Python CSV | cmp 结果 | sha256（两者相同） |
|---|---|---|---|---|
| 默认 | 1,677,253 B | 1,677,253 B | **IDENTICAL** | `6523e386…b25b238` |
| `--stop-words` | 1,674,689 B | 1,674,689 B | **IDENTICAL** | `332caa72…8322e708` |
| `--stem` | 958,633 B | 958,633 B | **IDENTICAL** | `cf280247…6c7228fb` |
| `--stem --stop-words` | 957,871 B | 957,871 B | **IDENTICAL** | `e7143b81…c7228fb` |

完整 sha256：default `6523e3863e54b752a6e53f6baa0b8d4b4b94537b68cec1bffff931a01b25b238`；
stop `332caa72bcbab2452d3ba6639f094825ecbd806c04032ea871f82c5d8322e708`；
stem `cf28024780c0a646565de197303fb9d45fc918e890255e6c1fca56447bd0a581`；
stem+stop `e7143b81341ea308199c8c476358f1b7448a56085b7635d21f0aed116c7228fb`。
日志：`reports/data/logs/tasks/wordcount-py-cmp.log`。4 份 CSV 均在 `reports/data/work/tasks/`。

### F16 count 3 次计时明细（每次独立进程，wall = time.time 差值）

| 配置 | run1 | run2 | run3 | 中位 |
|---|---|---|---|---|
| 默认 | 0.1335 s | 0.1373 s | 0.1344 s | **0.1344 s** |
| stop | 0.1462 s | 0.1445 s | 0.1447 s | **0.1447 s** |
| stem | 0.1483 s | 0.1543 s | 0.1529 s | **0.1529 s** |
| stem+stop | 0.1575 s | 0.1546 s | 0.1586 s | **0.1575 s** |

脚本：`reports/data/work/tasks/run_counts.sh`；日志：`reports/data/logs/tasks/count-timings.log`。
注意语义：测的是**进程整体**（启动 + 读 manifest + 读 195 个文本 + 计数 + 写 CSV），不是纯计数内核。

### F17 交付给图表的 CSV

| 文件（reports/data/csv/tasks/） | 内容 | 字节 | sha256 |
|---|---|---|---|
| `wordcount-default.csv` | 默认 4 列熵特征表，25,705 行 | 1,677,253 | `6523e386…b25b238` |
| `wordcount-stem-stop.csv` | 正式配置（停用词+词干）表，14,937 行 | 957,871 | `e7143b81…c7228fb` |
| `threshold_matrix.csv` | 任务 4 全矩阵，201 行（F36） | 8,907 | `246f8bfc…5166c2` |

原始 C++ 产出在 `reports/data/work/tasks/wordcount-*.csv`（含 stop/stem/keep-speakers 中间版本），
副本用 `cp` 生成、sha256 一致。

---

## C. 任务 2：倒排索引构建

### F18 四种构建配置总表

命令模板：`./build/mse build --index reports/data/work/tasks/<name>.bin [--stop-words data/stopwords.txt] [--stem]`，
构建脚本 `reports/data/work/tasks/run_builds.sh`，日志 `reports/data/logs/tasks/builds.log`。

| 配置 | flags（dump 实测） | documents | tokens | terms | postings | positions | 索引字节 | 内建 build time | invariants |
|---|---|---|---|---|---|---|---|---|---|
| raw | `(raw)` | 195 | 866,626 | 25,705 | 152,650 | 866,626 | 5,598,793 | 0.20 s | OK |
| stop | `stopwords` | 195 | 556,866 | 25,666 | 147,909 | 556,866 | 4,320,622 | 0.18 s | OK |
| stem | `stemmed` | 195 | 866,626 | 14,947 | 121,903 | 866,626 | 4,958,598 | 0.23 s | OK |
| stop+stem（正式） | `stopwords stemmed` | 195 | 556,866 | 14,937 | 117,704 | 556,866 | **3,685,655** | 0.19 s（3 次中位） | OK |

- 体积相对 raw：stop 77.17%（-22.83%）、stem 88.57%（-11.43%）、正式 **65.83%（-34.17%）**；
  正式相对 stem -25.67%、相对 stop -14.70%。
- 正式索引 sha256 `267c51a217b40771505fa4fd25314015fbd6e6c5e9fb58ab4b78106d7ae6ebae`，
  raw `d69dc6ea…976717`、stop `6b838fbc…717b96`、stem `3712f1a0…e3a814`（完整值见日志）。
- `postings` = posting 条数（term×doc 对），`positions` = 位置总数（= tokens）。
- flags 由索引头写出，`dump`/`query` 头部打印：raw `(raw)`、stop `stopwords`、stem `stemmed`、
  正式 `stopwords stemmed`（见 `reports/data/logs/tasks/index-flags-dictfile-v2.log`）。

### F19 正式配置：3 次构建、确定性与计时

| run | 内建 build time | 外部 wall | 索引字节 | sha256 |
|---|---|---|---|---|
| 1 | 0.19 s | 0.2563 s | 3,685,655 | `267c51a2…` |
| 2 | 0.22 s | 0.2908 s | 3,685,655 | `267c51a2…` |
| 3 | 0.19 s | 0.2583 s | 3,685,655 | `267c51a2…` |
| 中位 | **0.19 s** | **0.2583 s** | — | 3 次完全相同 |

命令：`./build/mse build --index reports/data/work/tasks/index-formal.bin --stop-words data/stopwords.txt --stem` ×3。
日志：`reports/data/logs/tasks/builds.log`、`reports/data/logs/tasks/timing-summary.log`。
每次运行都打印相同 dictionary 统计（splay comparisons=6,392,724, rotations=5,850,795, rehashes=0），
说明构建对同一输入完全确定。

### F20 三词典对比（正式配置，splay / hash / map）

命令：`./build/mse build --dict <name> --index reports/data/work/tasks/index-dict-<name>.bin --stop-words data/stopwords.txt --stem`，
每种 3 次。日志：`reports/data/logs/tasks/builds.log`、`reports/data/logs/tasks/builds-verify.log`。

| 词典 | comparisons | rotations | rehashes | 内建 build time（3 次） | 外部 wall 中位 | 索引字节 | 产物 sha256 |
|---|---|---|---|---|---|---|---|
| splay（主） | **6,392,724** | **5,850,795** | 0 | 0.19 / 0.19 / 0.20 s → 0.19 s | 0.2610 s | 3,685,655 | `267c51a2…` |
| hash | 688,494 | 0 | **11** | 0.09 / 0.09 / 0.10 s → 0.09 s | **0.1603 s** | 3,685,655 | `267c51a2…` |
| map（std::map 基线） | 9,435,694 | 0 | 0 | 0.15 / 0.14 / 0.14 s → 0.14 s | 0.2084 s | 3,685,655 | `267c51a2…` |

- 三种词典构建的索引文件与 F19 正式索引 **逐字节相同**（`cmp` 全部 IDENTICAL，同一 sha256），
  证明词典实现只影响构建过程、不影响持久化布局。
- hash 比较次数最少（688,494，约 splay 的 10.8%）且最快；splay 比较多但无 rehash；`std::map`
  比较次数最多（9,435,694）。所有 comparisons/rotations/rehashes 均为 C++ 内建计数，本轮实测。

### F21 压缩（v1 vs v2：docID/位置差分 + 字节对齐 varint）

命令：`./build/mse build --compress --index reports/data/work/tasks/index-formal-v2.bin --stop-words data/stopwords.txt --stem`（3 次）；
日志：`reports/data/logs/tasks/builds.log`、`reports/data/logs/tasks/builds-verify.log`。

| 版本 | 索引字节 | 相对 v1 | 内建 build time | 外部 wall 中位 | sha256 |
|---|---|---|---|---|---|
| v1 原始 u32 | 3,685,655 | 100% | 0.19 s | 0.2583 s | `267c51a2…` |
| v2 差分+varint | **1,725,694** | **46.82%**（省 1,959,961 B = 53.18%） | 0.19 s（3 次均 0.19） | 0.2560 s | `0d01c2fc…` |

- 压缩构建的处理管线与 v1 相同（dictionary 统计、tokens/terms/postings 完全相同），只改 postings 编码。
- 可读性验证：`./build/mse dump --index .../index-formal-v2.bin --term love --limit 2` 输出
  `term love: df=138, tf=2912`，position 列表与 v1 一致；日志 `reports/data/logs/tasks/dumps-basic.log`。
- v2 与 v1 的 `query --word osric --pretty` 输出除首行索引文件名外**逐字节相同**（归一化路径后
  `cmp` 一致），见 `reports/data/logs/tasks/query-dictfile-cmp.log`。

### F22 块式（SPIMI 式）构建：17 块、与内存构建逐字节一致

命令：`./build/mse build-blocks --index reports/data/work/tasks/index-blocks.bin --stop-words data/stopwords.txt --stem`
（另跑一次 `--compress`）。日志：`reports/data/logs/tasks/builds.log`、`builds-verify.log`。

| 指标 | 值 |
|---|---|
| blocks（runs） | **17**（预算 `--block-terms` 默认 4096） |
| 峰值活词（peak live terms） | **5,129** |
| run 临时字节 | **4,166,556 B**（用后即删） |
| scan time | 0.11 s |
| merge time | 0.03 s |
| 总 wall（含进程启动） | 0.2146 s |
| 产物 | v1 版 3,685,655 B / v2 版 1,725,694 B |
| invariants | OK |

- 与内存构建对比：v1 块式索引与 `index-formal.bin` **逐字节相同**（sha256 均 `267c51a2…`）；
  压缩块式与 `index-formal-v2.bin` **逐字节相同**（均 `0d01c2fc…`）。这是"块式构建产物与
  全内存构建二进制等价"的直接证据。

### F23 磁盘 B+Tree 词典 sidecar（v1 与 v2 各一组）

构建：`./build/mse build --index <idx>.bin --dict-file <idx>.bpt --stop-words data/stopwords.txt --stem`
（v2 再加 `--compress`）。日志：`reports/data/logs/tasks/dictfile-build.log`、`dumps-dictfile.log`。

| 项 | v1 | v2（压缩索引） |
|---|---|---|
| 索引字节 | 3,685,655 | 1,725,694 |
| sidecar 字节 | **237,568**（占索引 6.45%） | **237,568**（占索引 13.77%） |
| sidecar sha256 | `c23b6570…84b7842a` | `5c129d08…6b0c54e0` |
| 树高（dump 头） | height 2 | height 2 |

`dump --dict-file --term banquo --limit 3` 实测（两条路径数值一致）：
`term banquo: df=1, tf=27`，doc 33 "Macbeth" 前 12 个 positions `195 662 663 1256 1376 3500 3520 3558 3559 4337 4415 4440`（+15 more）。

| 冷查询指标 | v1 | v2 |
|---|---|---|
| dict reads | **2 page reads, 0 cache hits** | 2 page reads, 0 cache hits |
| index read | **8,308 B**（全量加载 3,685,655 B 的 0.225%） | **8,238 B**（全量 1,725,694 B 的 0.477%） |

`dump --dict-file --verify-all` 实测（v1 与 v2 相同）：
`verified : 14,937 terms, 0 mismatches`；`dict reads : 114 page reads, 29,819 cache hits`——逐词双路径对拍零差异。

### F24 dict-file 查询路径与全载路径一致（逐字节）

- v1：`query --index index-sidecar-v1.bin --stop-words data/stopwords.txt --word osric --pretty`
  与加 `--dict-file index-sidecar-v1.bpt` 的输出 `cmp` **IDENTICAL**。
- v2：同样对比（`index-sidecar-v2.bin` + `index-sidecar-v2.bpt`）`cmp` **IDENTICAL**；
  sha256 均 `67e59d78…c899fdc1`。

日志：`reports/data/logs/tasks/query-dictfile-cmp.log`、`reports/data/logs/tasks/index-flags-dictfile-v2.log`。

### F25 dump 示例（原始输出全文见日志）

| 场景 | 命令要点 | 关键输出 |
|---|---|---|
| 正式 v1：稀有词 | `dump --index index-formal.bin --term osric` | `term osric: df=1, tf=3`；doc 30 "Hamlet" positions `17629 17933 18173` |
| 正式 v1：高频词+位置 | `dump --term love --limit 3` | `df=138, tf=2912`；doc1 tf=85，doc2 tf=142，doc3 tf=20，`... (+135 more postings)` |
| raw 索引：停用词可检索 | `dump --index index-raw.bin --term the --limit 2` | `df=177, tf=28436`；doc1 tf=699、doc2 tf=674，`... (+175 more postings)` |
| v2 压缩索引可读 | `dump --index index-formal-v2.bin --term love --limit 2` | 与 v1 前两行 postings 相同 |

日志：`reports/data/logs/tasks/dumps-basic.log`。

### F26 索引文件头信息（逐个索引的第一手读数）

`dump` 第一行即索引头摘要；配合 `ls -l`：

| 索引 | 头信息（docs/terms/tokens） | flags | 字节 |
|---|---|---|---|
| index-raw.bin | 195 docs, 25,705 terms, 866,626 tokens | `(raw)` | 5,598,793 |
| index-stop.bin | 195 docs, 25,666 terms, 556,866 tokens | `stopwords` | 4,320,622 |
| index-stem.bin | 195 docs, 14,947 terms, 866,626 tokens | `stemmed` | 4,958,598 |
| index-formal.bin | 195 docs, 14,937 terms, 556,866 tokens | `stopwords stemmed` | 3,685,655 |
| index-formal-v2.bin | 195 docs, 14,937 terms, 556,866 tokens | `stopwords stemmed` | 1,725,694 |

日志：`reports/data/logs/tasks/index-flags-dictfile-v2.log`、`builds-verify.log`。
索引不是自描述文本格式，这里记录的是程序解析头部后打印的权威值；v1/v2 由头中的版本字段区分。

---

## D. 任务 3：查询程序与阈值

> 以下均用本轮构建的正式索引 `reports/data/work/tasks/index-formal.bin`
> （flags = stopwords stemmed）与 `--stop-words data/stopwords.txt`；raw 对照用 `index-raw.bin`。

### F27 单词查询 `--word osric --pretty`

`results : 1 documents`；doc 30 "Hamlet"，命中行 `> Osric, who brings back to him that you attend him in`。
命令：`./build/mse query --index reports/data/work/tasks/index-formal.bin --stop-words data/stopwords.txt --word osric --pretty`。
日志：`reports/data/logs/tasks/query-basic.log`。

### F28 单词查询 `--word love`（138 篇，全输出在日志）

- `results: 138 documents`（分母=195 篇）；默认按 tf 降序，前 5 篇：doc16 Two Gentlemen of Verona、
  doc35 Romeo and Juliet、doc2 As You Like It、doc5 Love's Labours Lost、doc9 A Midsummer Night's Dream。
- JSON 同轮：`hits` 138 条，tf 最高三篇 = doc16 tf195、doc35 tf165、doc2 tf142（与文本顺序一致）。
- 日志：`reports/data/logs/tasks/query-basic.log`（全文）、`query-json.log`。

### F29 短语查询 `--phrase "king richard" --top-x 3`

`results : 3 documents (--top-x 3)`：doc23 Henry VI, part 3（matched 2/2, tf 193）、doc26 Richard II
（2/2, tf 191）、doc27 Richard III（2/2, tf 140）。无 top-x 时基线为 **7 篇**（见 F38 矩阵 off 行）。
命令：`... --phrase "king richard" --top-x 3`；日志：`reports/data/logs/tasks/query-basic.log`。

### F30 短语退化：`--phrase "my lord"`（含停用词）

实测打印退化 note 并只查剩余词：
```
query      : phrase "my lord"
terms      : lord
note       : my -- stop word (excluded from the index)
results    : 42 documents
```
（前 3 篇按 tf：doc27 Richard III tf242、doc30 Hamlet tf220、doc19 Henry IV, part 2 tf202。）
日志：`reports/data/logs/tasks/query-basic.log`。JSON 的 notes 为 `[["my","stop word (excluded from the index)"]]`（`query-json-notes-and-planned.log`）。

### F31 多词查询 `--words "king queen" --min-match 2 --top-x 5`

`results : 5 documents (--top-x 5)`（截断前满足 ≥2/2 的是 33 篇）：doc23 Henry VI, part 3
（matched 2/2, tf 219）、doc24 Henry VIII（175）、doc26 Richard II（163）、doc22 Henry VI, part 2（155）、
doc27 Richard III（138）。对照：`--min-match 1` = 43 篇（并集），默认 min-match=0（AND）= 33 篇（F36）。
日志：`reports/data/logs/tasks/query-basic.log`、`query-threshold-mini.log`。

### F32 停用词与未登录词行为

| 查询 | terms | note | results |
|---|---|---|---|
| `--word the` | `(none)` | `the -- stop word (excluded from the index)` | **0** |
| `--word notaword` | `(none)` | `notaword -- not in the index` | **0** |
| raw 索引 `--word the --top-x 3` | `the` | — | **3 documents**（doc30 Hamlet、doc29 Coriolanus、doc20 Henry V） |

日志：`reports/data/logs/tasks/query-basic.log`、`query-raw-and-v2.log`。停用词在正式索引中不可检索，
在 raw 索引中可检索——两套索引的 flags 决定了解释器行为（同一查询程序自动按索引头启用 stopwords/stemmed 管线）。

### F33 词干化效果：`--word loves` 正式 vs raw

| 索引 | terms | results |
|---|---|---|
| 正式（stop+stem） | `love`（查询词被 Porter 归一） | **138 documents** |
| raw（无词干） | `loves`（原形匹配） | **43 documents** |
| raw 对照 `--word love` | `love` | **127 documents** |

即：词干化后 `loves` 与 `love` 命中同一词干族（138 篇）；不词干时 `loves` 只能命中 43 篇。
日志：`reports/data/logs/tasks/query-raw-and-v2.log`。

### F34 JSON 输出格式（`--json`）

顶层字段：`query`（原始查询串）、`mode`（`word`/`phrase`）、`terms`（经停用词/词干化处理后的索引词）、
`hits`（数组，每项 `{doc:int, matched:int, tf:int}`，顺序与文本输出一致）、`notes`（数组，每项
`[term, 原因]`，无 note 时为空数组）。例：
`{"query":"love","mode":"word","terms":["love"],"hits":[{"doc":16,"matched":1,"tf":195}, …],"notes":[]}`
（138 条 hits）；短语 JSON：`{"query":"king richard","mode":"phrase","terms":["king","richard"],"hits":[…3条], "notes":[]}`。
日志：`reports/data/logs/tasks/query-json.log`、`query-json-notes-and-planned.log`。

### F35 阈值接口小例（单查询，`query --word love` 等）

| 命令参数 | note / terms | results | 解释 |
|---|---|---|---|
| `--max-df 0.7` | `love -- df ratio above --max-df`，terms 空 | **0** | love df_ratio=0.707692 > 0.7，被阈值丢弃 |
| `--max-df 0.5` | 同上 | **0** | 同上（0.5 更严） |
| `--min-df 100` | 保留 love | **138** | love df=138 ≥ 100 |
| `--word osric --min-df 2` | `osric -- df below --min-df` | **0** | osric df=1 < 2 |
| `--top-x 5` | — | **5** | 截断 |
| `--top-x 10` | — | **10** | 截断 |
| `--top-x 20` | — | **20** | 截断 |
| `--words "king queen" --min-match 1` | terms king queen | **43** | 至少 1 词命中（并集） |

日志：`reports/data/logs/tasks/query-threshold-mini.log`（含被修正的首次误引号尝试，见 F41 异常清单第 4 条）。

### F36 任务 4 阈值矩阵：本轮运行 201 条测量

命令（输出强制到交付 CSV）：
`python3 tools/threshold_matrix.py --index reports/data/work/tasks/index-formal.bin --stop-words data/stopwords.txt --csv reports/data/csv/tasks/threshold_matrix.csv --svg reports/data/work/tasks/threshold_matrix.svg`

| 项 | 值 |
|---|---|
| measurement 行数 | **201**（+表头 = 202 行 CSV，`wc -l` 实测 202） |
| 查询数 | 15（high/mid/low/name/phrase/phrase-stop/bool/stopword 8 类） |
| 参数网格 | max-df 5 档、min-df 4 档、top-x 3 档、min-match 3 档 |
| 行分布 | off 15、max-df 75、min-df 60、top-x 45、min-match 6（合计 201） |
| 单次查询 wall（含进程启动） | min 17.1 / 中位 **19.2** / 均值 19.60 / max 29.9 ms（N=201） |
| 总运行时间 | 4.05 s（进程外 wall） |
| CSV | `reports/data/csv/tasks/threshold_matrix.csv`，sha256 `246f8bfcb60882e40c1b8fd623ef6370fed51a7595551c141d732018df5166c2` |
| SVG（中间产物，放 work） | `reports/data/work/tasks/threshold_matrix.svg`（10,456 B） |

日志：`reports/data/logs/tasks/threshold-matrix.log`（含 4 张 pivot 表全文）、
`reports/data/logs/tasks/threshold-analysis.log`。CSV 列：`query,category,mode,param,value,results,jaccard,notes,ms`。

### F37 阈值矩阵基线返回数（15 查询，无阈值）

| 查询 | 类型 | 基线 results | 说明 |
|---|---|---|---|
| love | word | 138 | df 138/195=0.7077 |
| sweet | word | 90 | df 90 |
| good | word | 57 | |
| night | word | 56 | |
| sword | word | 37 | |
| moon | word | 35 | |
| banquo | word | 1 | 名字 df=1 |
| osric | word | 1 | 名字 df=1 |
| king richard | phrase | 7 | 两词都在索引 |
| good night | phrase | 23 | |
| my lord | phrase-stop | 42 | my 是停用词 → 退化为 lord |
| king queen | bool(words) | 33 | 默认 AND（min-match=0） |
| sweet sword moon | bool(words) | 30 | 默认 AND |
| the | stopword | 0 | 停用词不可检索 |
| of | stopword | 0 | 停用词不可检索 |

来源：CSV 中 `param=off` 的 15 行；同时与 F28/F29/F30/F31 的单查询结果互相印证。

### F38 阈值矩阵代表性读数（含 `30→90` 现象）

| 查询 | 参数 | 基线→取值 results（jaccard） | 解释 |
|---|---|---|---|
| love | max-df 0.9 / 0.7 | 138 → 138(1.00) / **0(0.00)** | df_ratio 0.7077：0.7 档起被丢，notes=1 |
| sweet | max-df 0.3 / 0.1 | 90 → 90(1.00) / **0(0.00)** | df_ratio 0.4615，0.3 起被丢 |
| good / night | max-df 0.1 | 57/56 → 0(0.00) | df_ratio 0.29，仅最严档丢 |
| king queen | max-df 0.1 | 33 → 0(0.00) | 任一词被丢则 AND 失败 |
| sweet sword moon | min-df 50 | 30 → **90(0.3333)** | **反直觉但正确**：sword(df37)/moon(df35) 被丢，只剩 sweet(90 篇)，约束退化为单词→ 90 篇；notes=2 |
| sword / moon | min-df 50 | 37/35 → 0(0.00) | 单词查询被自身 df 阈值丢弃 |
| banquo / osric | min-df 2 | 1 → 0(0.00) | df=1 < 2 |
| king queen | min-match 1 / 2 / 3 | 33 → **43(0.7674)** / 33(1.00) / 33(1.00) | 1 为并集；≥2 与默认 AND 等价（只有 2 词，k=3 不可能满足→与 AND 同结果） |
| sweet sword moon | min-match 1 / 2 / 3 | 30 → **93(0.3226)** / **39(0.7692)** / 30(1.00) | 1=并集，2=任两词，3=AND |
| love | top-x 5 / 10 / 20 | 138 → 5(0.0362) / 10(0.0725) / 20(0.1449) | 截断；jaccard=top-x/138 近似 |
| sword | top-x 5 / 10 / 20 | 37 → 5(0.1351) / 10(0.2703) / 20(0.5405) | |
| good night | top-x 20 | 23 → 20(0.8696) | |

来源：`reports/data/csv/tasks/threshold_matrix.csv`；完整 pivot 表在
`reports/data/logs/tasks/threshold-matrix.log`。

### F39 丢弃词（notes）与结果集完全丢失的行

- `notes` 列 = 被阈值丢弃的词数。实测分布（按 param/value 聚合）：
  max-df 0.9/0.7/0.5 各 3–4 条 notes=1；max-df 0.3 有 6 条 notes=1；max-df 0.1 有 9 条 notes=1、
  1 条 notes=2、1 条 notes=3（`sweet sword moon` 三词全丢）；min-df 2/5/20 各 5 条 notes=1；
  min-df 50 有 7 条 notes=1、2 条 notes=2；`off` 列有 3 条 notes=1（my lord / the / of 各 1 条），
  `top-x` 列 9 条 notes=1（同样是 my lord / the / of，各在 5/10/20 三档出现一次）。
- jaccard=0（结果集全丢）共 23 条，全部出现在 max-df 0.7 以下的 love/sweet/good/night/sword/moon、
  max-df 0.1 的 king queen/sweet sword moon，以及 min-df 2 以上的 banquo/osric、min-df 50 的
  sword/moon/king queen。明细：`reports/data/logs/tasks/threshold-analysis.log`。

---

## E. CLI 与异常/缺口

### F40 CLI 无参数 usage

`./build/mse`（无参数）打印完整 usage，rc=0；顶层子命令 **9 个**：stats、tokenize、count、stopwords、
build、build-blocks、bptree-bench、dump、query；末尾 `planned: shell, selftest`。
日志：`reports/data/logs/tasks/usage.log`（全文）。
实测 `./build/mse shell` 与 `./build/mse selftest` 均返回 rc=2，输出
`unknown or not-yet-implemented command: shell|selftest` 并打印 usage（与文档"规划中"一致）；
日志：`reports/data/logs/tasks/query-json-notes-and-planned.log`。

### F41 异常、口径坑与本轮缺口（如实记录）

1. **`ls data/raw/*.html` 只有 6 个**：镜像的 HTML 分散在 41 个子目录，递归统计为 1,211 个
   （与 SOURCE.txt 的 `html files: 1211` 一致）。写报告若引用"1211"应注明是递归口径。
2. **`data2/data/manifest.tsv` 的 text 路径是相对语料根 `data2/`**：引擎按 `dirname(dirname(manifest))`
   解析；`analyze_manifest.py` 初版按 cwd 直接 `isfile` 误报 3 个缺失，已修正口径说明（引擎行为正常）。
3. **计时受并行负载影响**：本次测量期间 analyst-verify 在并行跑 ctest/验证任务，墙钟时间已注明
   为"量级参考"；C++ 内建计时的重复性更好（如正式构建 0.19/0.22/0.19 s）。
4. **`--words "king queen"` 在 shell for 循环里未加引号会被拆成两个参数**（`--words king` + 位置参数
   `queen`），首次小矩阵因此只查到 `king`；已改用显式引号命令重跑，结果见 F35（不是程序缺陷）。
5. **路径命名小坑**：计时脚本内部 run 名为 `stem_stop`，而 CSV 文件名用 `wordcount-stem-stop.csv`
   （连字符）；首次 cmp 报"文件不存在"，按实际文件名重比后逐字节一致（F15）。
6. **未测/不归我**：bptree-bench 规模实验、50 万文档合成语料、ctest 明细与断言数、brute_force.py /
   check_phrases.py 交叉验证、verify-all、RFC 语料端到端——按分工由 analyst-verify 负责，本文件不含其数字。
   RFC 只做了 `stats` 与 `count` 两项基础读数（F2）。
7. **`--keep-headings`/`--keep-stage` 未单独测量**（任务只要求 `--keep-speakers` 对照，F12）。
8. 查询主路径逐条串行执行，未做并发/多线程查询实验（项目为单线程 CLI）。

### F42 产物索引（供 writer/figure-maker 取用）

- **交付 CSV**：`reports/data/csv/tasks/wordcount-default.csv`、`reports/data/csv/tasks/wordcount-stem-stop.csv`、
  `reports/data/csv/tasks/threshold_matrix.csv`。
- **日志**（`reports/data/logs/tasks/`，共 30 个）：env、corpus-stats、manifest-analysis、stopwords-list、
  count-timings、count-summaries、count-analysis、count-csv-meta、wordcount-py-cmp、stopwords-derive、
  stopwords-derived-files、builds、builds-verify、dictfile-build、dumps-basic、dumps-dictfile、
  index-flags-dictfile-v2、timing-summary、query-basic、query-raw-and-v2、query-json、query-json-notes-and-planned、
  query-threshold-mini、query-dictfile-cmp、threshold-matrix、threshold-analysis、usage、rfc-count-and-aggregates、
  env-corpus-more、probe-count（另有若干）。
- **中间产物/脚本**（`reports/data/work/tasks/`）：`index-*.bin`（raw/stop/stem/formal/formal-v2/dict-*/blocks/
  blocks-v2/sidecar-*）、`*.bpt` sidecar、`wordcount-*.csv`（4 配置+keep-speakers+RFC）、
  `stopwords/derived-*.txt`、`q-*.txt` 查询输出、`threshold_matrix.svg`，
  以及可复现脚本 `analyze_manifest.py`、`analyze_count.py`、`analyze_threshold.py`、`run_counts.sh`、`run_builds.sh`。
- 所有可复现命令均在上文各 Fact 的"命令"处给出；脚本内路径均为相对 `proj1/` 根。

---

*本文件由 analyst-core 于 2026-10-20 本轮重新运行后生成；F1–F42 全部数字来自本轮命令输出。*
