#!/usr/bin/env python3
"""Comment ratio for the C++ sources (course: comments >= 30% of code).

Method (documented for the report): a small state machine scans each file
char-by-char, tracking /* block comments */, // line comments and string/char
literals (so "http://..." inside a string is NOT counted as a comment).  A
line is classified as:
  blank        -- only whitespace
  comment      -- its first non-space character starts a comment (// or /*..*/)
  inline       -- contains code followed by a // or /* comment
  code         -- contains code only
Reported metric: comment_ratio = comment_only / (comment_only + inline + code),
i.e. the fraction of non-blank source lines that are pure comment lines.
"""
import glob
import sys


def classify(path):
    text = open(path, encoding="utf-8").read()
    i, n = 0, len(text)
    in_block = False
    in_str = False
    in_chr = False
    stats = {"blank": 0, "comment": 0, "inline": 0, "code": 0}
    line_has_code = False
    line_has_comment = False
    line_only_comment = False
    first_nonspace_seen = False
    at_line_start = True
    while i < n:
        c = text[i]
        nxt = text[i + 1] if i + 1 < n else ""
        if c == "\n":
            if not line_has_code and not line_has_comment:
                stats["blank"] += 1
            elif line_has_code and line_has_comment:
                stats["inline"] += 1
            elif line_has_comment:
                stats["comment"] += 1
            else:
                stats["code"] += 1
            line_has_code = line_has_comment = False
            first_nonspace_seen = False
            at_line_start = True
            i += 1
            continue
        if in_block:
            line_has_comment = True
            if not first_nonspace_seen and not c.isspace():
                line_only_comment = True
                first_nonspace_seen = True
            if c == "*" and nxt == "/":
                in_block = False
                i += 2
            else:
                i += 1
            continue
        if in_str:
            line_has_code = True
            if c == "\\":
                i += 2
                continue
            if c == '"':
                in_str = False
            i += 1
            continue
        if in_chr:
            line_has_code = True
            if c == "\\":
                i += 2
                continue
            if c == "'":
                in_chr = False
            i += 1
            continue
        if c == "/" and nxt == "/":
            line_has_comment = True
            if not first_nonspace_seen:
                line_only_comment = True
                first_nonspace_seen = True
            # skip to newline (a line comment runs to end of line)
            j = text.find("\n", i)
            i = n if j == -1 else j
            continue
        if c == "/" and nxt == "*":
            line_has_comment = True
            if not first_nonspace_seen:
                line_only_comment = True
                first_nonspace_seen = True
            in_block = True
            i += 2
            continue
        if not c.isspace():
            line_has_code = True
            first_nonspace_seen = True
        if c == '"':
            in_str = True
        elif c == "'":
            in_chr = True
        i += 1
    return stats


def summarize(files, label):
    total = {"blank": 0, "comment": 0, "inline": 0, "code": 0}
    for path in files:
        s = classify(path)
        for k in total:
            total[k] += s[k]
    nonblank = total["comment"] + total["inline"] + total["code"]
    ratio = 100.0 * total["comment"] / nonblank if nonblank else 0.0
    print(f"{label:<28} files={len(files):3d} lines={nonblank:6d} "
          f"comment={total['comment']:5d} inline={total['inline']:4d} "
          f"code={total['code']:6d} blank={total['blank']:5d} "
          f"comment_ratio={ratio:.1f}%")
    return total, ratio


src = sorted(glob.glob("src/*.cpp"))
hdr = sorted(glob.glob("include/*.hpp"))
tests = sorted(glob.glob("tests/*.cpp"))
print("comment_ratio = comment_only_lines / non_blank_lines (state machine; "
      "strings not counted as comments)")
summarize(src, "src/*.cpp")
summarize(hdr, "include/*.hpp")
summarize(src + hdr, "C++ core (src+include)")
summarize(tests, "tests/*.cpp")
