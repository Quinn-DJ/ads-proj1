#!/bin/bash
# bptree-bench: 3 runs for 100k/1M/10M, single run for 30M/50M (timing noisy under
# parallel teammate load; structural columns are deterministic).
set -u
ROOT="$(cd "$(dirname "$0")/../../../.." && pwd)"
cd "$ROOT" || exit 1
LOG="$ROOT/reports/data/logs/verify/bptree-bench.log"
: > "$LOG"
run_one() { # keys rep
  local keys=$1 rep=$2
  echo "===== keys=$keys rep=$rep =====" >> "$LOG"
  /usr/bin/time -p ./build/mse bptree-bench --keys "$keys" --lookups 1000 \
      --out "$ROOT/reports/data/work/verify/bpt-$keys.bpt" >> "$LOG" 2>&1
}
for keys in 100000 1000000 10000000; do
  for rep in 1 2 3; do run_one "$keys" "$rep"; done
done
for keys in 30000000 50000000; do run_one "$keys" 1; done
rm -f "$ROOT"/reports/data/work/verify/bpt-*.bpt
echo "ALL DONE" >> "$LOG"
