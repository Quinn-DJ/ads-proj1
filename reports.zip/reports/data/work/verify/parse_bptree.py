#!/usr/bin/env python3
"""Parse bptree-bench.log -> reports/data/csv/verify/bptree-bench.csv.

Per repetition block we read: keys, height, pages, file bytes, bytes/key,
page reads, and the /usr/bin/time `real` seconds.  For keys with 3 reps we
report the median seconds (structure is deterministic and verified identical);
30M/50M are single-run and marked as such in results-verify.md.
"""
import re, statistics

LOG = "reports/data/logs/verify/bptree-bench.log"
OUT = "reports/data/csv/verify/bptree-bench.csv"

block_re = re.compile(r"===== keys=(\d+) rep=(\d+) =====")
rows = []
cur = {}
for line in open(LOG):
    m = block_re.match(line)
    if m:
        if cur:
            rows.append(cur)
        cur = {"keys": int(m.group(1)), "rep": int(m.group(2))}
        continue
    def grab(pattern, key, cast):
        global cur
        mm = re.search(pattern, line)
        if mm:
            cur[key] = cast(mm.group(1))
    grab(r"height\s*: (\d+)", "height", int)
    grab(r"pages\s*: (\d+)", "pages", int)
    grab(r"\((\d+) bytes,", "file_bytes", int)
    grab(r"([\d.]+) bytes/key\)", "bpk", float)
    grab(r"\(cache = 1 page\)", "lookups_dummy", int) if False else None
    grab(r"lookups\s*: (\d+) verified", "lookups", int)
    grab(r"verified, ([\d.]+) page reads", "page_reads", float)
    grab(r"^real ([\d.]+)", "seconds", float)
    grab(r"build\s*: ([\d.]+) s", "build_s", float)
if cur:
    rows.append(cur)

by_keys = {}
for row in rows:
    by_keys.setdefault(row["keys"], []).append(row)

with open(OUT, "w", encoding="utf-8") as out:
    out.write("keys,height,pages,file_bytes,bytes_per_key,lookups,page_reads,seconds\n")
    for keys in sorted(by_keys):
        reps = by_keys[keys]
        base = reps[0]
        secs = [r["seconds"] for r in reps if "seconds" in r]
        out.write(f"{keys},{base['height']},{base['pages']},{base['file_bytes']},"
                  f"{base['bpk']:.4f},{base['lookups']},{base['page_reads']:.2f},"
                  f"{statistics.median(secs):.3f}\n")
        print(f"keys={keys} reps={len(reps)} secs={secs} median={statistics.median(secs):.3f} "
              f"pages={base['pages']} file={base['file_bytes']} bpk={base['bpk']} reads={base['page_reads']}")
