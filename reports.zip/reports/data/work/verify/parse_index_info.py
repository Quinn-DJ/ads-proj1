#!/usr/bin/env python3
"""Report header / document-table / term-table totals of an MSE index file.

Independent parse of the v1/v2 layout (same layout for header + doc table +
term table; only the postings section encoding differs).  build-blocks does not
print a postings count, so this derives it from the frozen term table
(postings = sum df, positions = sum tf) without trusting the builder's printout.
"""
import struct
import sys


def main(path):
    data = open(path, "rb").read()
    if data[:4] != b"MSE1":
        sys.exit("bad magic")
    version, flags, doc_count, term_count = struct.unpack_from("<IIII", data, 4)
    token_count = struct.unpack_from("<Q", data, 20)[0]
    pos = 28
    for _ in range(doc_count):
        doc_id, kept, length = struct.unpack_from("<III", data, pos)
        pos += 12 + length
    sum_df = 0
    sum_tf = 0
    for _ in range(term_count):
        length = struct.unpack_from("<I", data, pos)[0]
        pos += 4 + length
        df = struct.unpack_from("<I", data, pos)[0]
        tf = struct.unpack_from("<Q", data, pos + 4)[0]
        pos += 24  # df u32 + tf u64 + offset u64 + blocksize u32
        sum_df += df
        sum_tf += tf
    print(f"index      : {path}")
    print(f"version    : {version}")
    print(f"flags      : {flags}")
    print(f"documents  : {doc_count}")
    print(f"terms      : {term_count}")
    print(f"postings   : {sum_df}")
    print(f"positions  : {sum_tf}")
    print(f"tokens     : {token_count}")
    print(f"file bytes : {len(data)}")
    print(f"term-table end offset: {pos}")


if __name__ == "__main__":
    main(sys.argv[1])
