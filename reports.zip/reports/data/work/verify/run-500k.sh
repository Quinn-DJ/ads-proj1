#!/bin/bash
# 500k-document synthetic corpus: stats, block build (v1 + compressed), in-memory build.
# Peak RSS via /usr/bin/time -l (macOS "maximum resident set size" in bytes).
set -u
ROOT="$(cd "$(dirname "$0")/../../../.." && pwd)"
cd "$ROOT" || exit 1
CORPUS=/tmp/mse-scale-corpus-500k
W="$ROOT/reports/data/work/verify"
LOG="$ROOT/reports/data/logs/verify/500k-experiments.log"
: > "$LOG"
run() { echo; echo "===== $* =====" >> "$LOG"; }
run "mse stats (500k docs)"
/usr/bin/time -l ./build/mse stats --manifest "$CORPUS/data/manifest.tsv" >> "$LOG" 2>&1
run "mse build-blocks --block-terms 4096 (v1)"
/usr/bin/time -l ./build/mse build-blocks --manifest "$CORPUS/data/manifest.tsv" \
    --block-terms 4096 --index "$W/scale-500k-v1.bin" >> "$LOG" 2>&1
run "mse build-blocks --block-terms 4096 --compress (v2)"
/usr/bin/time -l ./build/mse build-blocks --manifest "$CORPUS/data/manifest.tsv" \
    --block-terms 4096 --compress --index "$W/scale-500k-v2.bin" >> "$LOG" 2>&1
run "mse build (in-memory, v1)"
/usr/bin/time -l ./build/mse build --manifest "$CORPUS/data/manifest.tsv" \
    --index "$W/scale-500k-mem.bin" >> "$LOG" 2>&1
run "index sizes"
ls -l "$W"/scale-500k-v1.bin "$W"/scale-500k-v2.bin "$W"/scale-500k-mem.bin >> "$LOG" 2>&1
echo; echo "ALL DONE" >> "$LOG"
