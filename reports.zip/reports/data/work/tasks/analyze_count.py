#!/usr/bin/env python3
"""Task B: analyse mse count CSVs (columns: rank,term,tf,df,df_ratio,tf_share,
stop_candidate,entropy,entropy_norm,entropy_rate_norm) written by this run."""
import csv, sys

DEFAULT = "reports/data/work/tasks/wordcount-default.csv"
CONFIGS = {
    "default":    ("reports/data/work/tasks/wordcount-default.csv", 195, 866626),
    "stop":       ("reports/data/work/tasks/wordcount-stop.csv", 195, 556866),
    "stem":       ("reports/data/work/tasks/wordcount-stem.csv", 195, 866626),
    "stem+stop":  ("reports/data/work/tasks/wordcount-stem-stop.csv", 195, 556866),
}

def load(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))

rows = load(DEFAULT)
ndocs = 195
print("### default-config CSV shape")
print("rows:", len(rows), "| header:", ",".join(rows[0].keys()))

print("\n### top 10 (default config, rank order = CSV order)")
print("rank\tterm\ttf\tdf\tdf_ratio\ttf_share\tstop_candidate\tentropy\tentropy_norm\tentropy_rate_norm")
for r in rows[:10]:
    print("\t".join([r["rank"], r["term"], r["tf"], r["df"], r["df_ratio"],
                     r["tf_share"], r["stop_candidate"], r["entropy"],
                     r["entropy_norm"], r["entropy_rate_norm"]]))

print("\n### hapax / distinct bookkeeping per config")
for name, (path, nd, ntokens) in CONFIGS.items():
    rr = load(path)
    hapax = sum(1 for r in rr if r["tf"] == "1")
    one_doc = sum(1 for r in rr if r["df"] == "1")
    print(f"{name:10s} rows(distinct)={len(rr):6d} hapax(tf==1)={hapax:5d} "
          f"hapax/distinct={hapax/len(rr)*100:5.2f}% hapax/tokens={hapax/ntokens*100:6.3f}% "
          f"df==1={one_doc:5d} tokens={ntokens}")

print("\n### default config: tf_share/df_ratio gates (stop candidate rule)")
cand = [r for r in rows if float(r["df_ratio"]) >= 0.75 and float(r["tf_share"]) >= 0.001]
print(f"df_ratio>=0.75 & tf_share>=0.001 -> {len(cand)} terms:",
      " ".join(r["term"] for r in cand))

print("\n### selected-word rows (default config; '-' = term absent from CSV)")
WANTED = ["the","and","i","to","of","a","you","my","love","king","heart",
          "sweet","man","wherefore","osric","banquo","thou","hath"]
by_term = {r["term"]: r for r in rows}
hdr = "term\ttf\tdf\tdf_ratio\ttf_share\tentropy\tentropy_norm\tentropy_rate_norm\trank"
print(hdr)
for w in WANTED:
    r = by_term.get(w)
    if r is None:
        print(f"{w}\t-\t-\t-\t-\t-\t-\t-\t-")
    else:
        print("\t".join([w, r["tf"], r["df"], r["df_ratio"], r["tf_share"],
                         r["entropy"], r["entropy_norm"], r["entropy_rate_norm"], r["rank"]]))

print("\n### df_ratio-threshold sensitivity (tf_share>=0.001 fixed, from default CSV)")
print("rule: candidate <=> df_ratio >= T AND tf_share >= 0.001 (same as C++ stop_candidate, T=0.75)")
ths = [0.90, 0.75, 0.70, 0.65, 0.60, 0.50, 0.40]
prev = None
for t in ths:
    sel = [r for r in rows if float(r["df_ratio"]) >= t and float(r["tf_share"]) >= 0.001]
    terms = [r["term"] for r in sel]
    if prev is None:
        new = []
    else:
        new = [w for w in terms if w not in prev]
    print(f"T={t:.2f}: candidates={len(terms):3d} new_vs_stricter={len(new):3d} "
          f"new=[{' '.join(new) if new else '-'}]")
    print("  list:", " ".join(terms) if terms else "-")
    prev = set(terms)
