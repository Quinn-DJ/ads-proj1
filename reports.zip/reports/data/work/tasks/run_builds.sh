#!/usr/bin/env bash
# Task C: index builds (raw/stop/stem/formal), dict variants, compression, blocks.
set -u
W=reports/data/work/tasks
wall() { python3 -c 'import time;print(f"{time.time():.6f}")'; }
t() { local t0=$(wall); "$@"; local rc=$?; local t1=$(wall); python3 -c "print(f\"WALL={$t1-$t0:.4f}s rc=$rc\")"; return $rc; }

echo "===== 1. raw (no stopwords, no stemming) ====="
t ./build/mse build --index "$W/index-raw.bin"
echo
echo "===== 2. stop words only ====="
t ./build/mse build --index "$W/index-stop.bin" --stop-words data/stopwords.txt
echo
echo "===== 3. stemming only ====="
t ./build/mse build --index "$W/index-stem.bin" --stem
echo
echo "===== 4. formal = stop+stem, 3 timed builds (same output path) ====="
for i in 1 2 3; do t ./build/mse build --index "$W/index-formal.bin" --stop-words data/stopwords.txt --stem; done
echo
echo "===== 5. dictionary variants on formal config (3 builds each) ====="
for d in splay hash map; do
  for i in 1 2 3; do
    echo "--- dict=$d run $i"
    t ./build/mse build --index "$W/index-dict-$d.bin" --dict "$d" --stop-words data/stopwords.txt --stem
  done
done
echo
echo "===== 6. compression v2 on formal config (3 timed builds) ====="
for i in 1 2 3; do t ./build/mse build --index "$W/index-formal-v2.bin" --compress --stop-words data/stopwords.txt --stem; done
echo
echo "===== 7. block-wise build (formal config) ====="
t ./build/mse build-blocks --index "$W/index-blocks.bin" --stop-words data/stopwords.txt --stem
echo
echo "===== 8. block-wise build compressed (formal config) ====="
t ./build/mse build-blocks --index "$W/index-blocks-v2.bin" --compress --stop-words data/stopwords.txt --stem
