#!/usr/bin/env python3
"""Task 4 input: summarise reports/data/csv/tasks/threshold_matrix.csv
(freshly produced by tools/threshold_matrix.py in this run)."""
import csv, statistics
P = "reports/data/csv/tasks/threshold_matrix.csv"
rows = list(csv.DictReader(open(P, newline="")))
print(f"measurement rows: {len(rows)} (+1 header line = {len(rows)+1} lines)")
from collections import Counter
print("rows per param:", dict(Counter(r["param"] for r in rows)))
print("rows per category:", dict(Counter(r["category"] for r in rows)))
print("distinct queries:", len({r["query"] for r in rows}))
ms = [float(r["ms"]) for r in rows]
print(f"per-query wall ms (includes process start, N={len(ms)}): "
      f"min={min(ms):.1f} median={statistics.median(ms):.1f} mean={statistics.mean(ms):.2f} max={max(ms):.1f}")

def show(query, param=None):
    for r in rows:
        if r["query"] == query and (param is None or r["param"] == param):
            print(f"  {query:16s} param={r['param']:9s} value={r['value']:>4s} "
                  f"results={r['results']:>3s} jaccard={r['jaccard']:>5s} notes={r['notes']} ms={r['ms']}")

print("\n### representative rows")
for q in ["love"]:
    show(q, "off"); show(q, "max-df"); show(q, "top-x")
print()
show("sweet sword moon", "off"); show("sweet sword moon", "min-df"); show("sweet sword moon", "min-match")
print()
show("king queen", "off"); show("king queen", "min-match")
print()
show("osric", "min-df")
print()
show("banquo", "off")

print("\n### dropped-term notes (notes>0), grouped by param/value")
seen = Counter()
for r in rows:
    if int(r["notes"]) > 0:
        seen[(r["param"], r["value"], r["notes"])] += 1
for (p, v, n), c in sorted(seen.items()):
    print(f"  param={p:9s} value={v:>4s} notes(dropped terms)={n} -> {c} measurements")

print("\n### all rows with jaccard==0 (complete result-set loss)")
for r in rows:
    if r["jaccard"] == "0.0":
        print(f"  {r['query']:16s} param={r['param']:9s} value={r['value']:>4s} base_results varies, results={r['results']}")
