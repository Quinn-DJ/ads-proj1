#!/usr/bin/env python3
"""Task A: manifest/corpus baselines. Reads data/manifest.tsv (and data2) only."""
import csv, sys, collections
def load(path):
    rows = []
    with open(path, newline='', encoding='utf-8') as f:
        r = csv.DictReader(f, delimiter='\t')
        for row in r: rows.append(row)
    return rows

def report(path, label):
    rows = load(path)
    print(f"== {label}: {path} ==")
    print(f"documents: {len(rows)}")
    print("fields:", ",".join(rows[0].keys()))
    for field in ("kind", "category", "format"):
        if field in rows[0]:
            c = collections.Counter(r[field] for r in rows)
            print(f"{field} distribution ({len(c)} values):")
            for k, v in c.most_common():
                print(f"  {k}\t{v}")
    # duplicate docids
    ids = [r["docid"] for r in rows]
    print("unique docids:", len(set(ids)), "| duplicate docids:", len(ids)-len(set(ids)))
    # text file existence
    import os
    missing = [r["text"] for r in rows if not os.path.isfile(r["text"])]
    print("missing text files:", len(missing), missing[:3])

report("data/manifest.tsv", "main corpus (Shakespeare)")
report("data2/data/manifest.tsv", "second corpus (IETF RFC)")
