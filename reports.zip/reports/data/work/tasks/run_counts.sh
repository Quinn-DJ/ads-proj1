#!/usr/bin/env bash
# Task B: 4 count configs x 3 timed runs. CSV -> reports/data/work/tasks/.
set -u
W=reports/data/work/tasks
L=reports/data/logs/tasks
run3() { # name, args...
  local name=$1; shift
  local out
  for i in 1 2 3; do
    local t0=$(python3 -c 'import time;print(time.time())')
    "$@" > "$W/${name}.run${i}.txt" 2>&1
    local rc=$?
    local t1=$(python3 -c 'import time;print(time.time())')
    echo "RUN $i rc=$rc wall=$(python3 -c "print(f'{$t1-$t0:.4f}')")"
  done
}
echo "### default"
run3 default ./build/mse count --top 50 --csv "$W/wordcount-default.csv"
echo "### stop"
run3 stop ./build/mse count --top 50 --stop-words data/stopwords.txt --csv "$W/wordcount-stop.csv"
echo "### stem"
run3 stem ./build/mse count --top 50 --stem --csv "$W/wordcount-stem.csv"
echo "### stop+stem"
run3 stem_stop ./build/mse count --top 50 --stop-words data/stopwords.txt --stem --csv "$W/wordcount-stem-stop.csv"
echo "### keep-speakers (no csv written)"
./build/mse count --top 5 --keep-speakers --csv "$W/wordcount-keep-speakers.csv" > "$W/keep-speakers.txt" 2>&1; echo "rc=$?"
