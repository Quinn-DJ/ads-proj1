#!/usr/bin/env python3
"""analyze_preprocess.py -- fresh verification of the preprocessing claims.

This is the evidence script behind reports/data/results-preprocess.md. It:

1. re-runs the HTML extractor's parser over data/raw (fresh, in-memory) and
   classifies every relocated leading [stage fragment] into
   A = the whole line was one bracket, B = a leading fragment with text after;
2. re-parses the committed text layer with the *current* line-marker spec and
   counts body lines that a naive "first char only" rule would wrongly drop;
3. checks the ASCII-only premise, the elegy malformed-tag case and the
   <h3>None</h3> conversion artifact;
4. recomputes the body-token arithmetic 866,626 + B tokens = pre-fix 867,475.

Output is plain text on stdout (captured into reports/data/logs/preprocess/).
"""

import hashlib
import re
import sys
from pathlib import Path

PROJ = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(PROJ / "tools"))
import extract as E  # noqa: E402

TOKEN_RE = re.compile(r"[A-Za-z]+(?:'[A-Za-z]+)*")
TEXT = PROJ / "data" / "text"
RAW = PROJ / "data" / "raw"

stats = {"A": 0, "A_tokens": 0, "B": 0, "B_tokens": 0,
         "empty_fragment": 0}

_orig_emit = E.PageParser._emit_body


def emit(self, text):
    first = True
    while text.startswith("["):
        close = text.find("]")
        if close == -1:
            break
        fragment = text[1:close].strip()
        rest = text[close + 1:].strip()
        if not fragment:
            stats["empty_fragment"] += 1
            text = rest
            if not text:
                return
            first = False
            continue
        tokens = len(TOKEN_RE.findall(fragment))
        if first and rest == "":
            stats["A"] += 1
            stats["A_tokens"] += tokens
        else:
            stats["B"] += 1
            stats["B_tokens"] += tokens
        text = rest
        if not text:
            return
        first = False
    _orig_emit(self, text)


E.PageParser._emit_body = emit


def kind_of(line):
    """Mirror src/corpus.cpp classifyLine (the both-ends rule)."""
    if len(line) >= 2 and line[0] == "[" and line[-1] == "]":
        return "heading"
    if len(line) >= 2 and line[0] == "(" and line[-1] == ")":
        return "stage"
    if line and line[0] == "@":
        return "speaker"
    return "body"


def main():
    # ---- 1. fresh parser run over data/raw --------------------------------
    docs = E.build_doc_list(RAW)
    c_forms = []
    body_tokens = 0
    hazard_lines = []
    for kind, category, title, src_rel in docs:
        parser = E.PageParser()
        parser.feed((RAW / src_rel).read_text(encoding="latin-1"))
        parser.close()
        for line in parser.lines:
            k = kind_of(line)
            if k == "body":
                body_tokens += len(TOKEN_RE.findall(line))
                # C class: square brackets left inside a body line
                for m in re.finditer(r"\[[^\]]*\]", line):
                    if m.start() > 0 or not line.startswith("["):
                        c_forms.append((title, line[max(0, m.start() - 25):m.end() + 25]))
                # a naive "first char" rule would drop this body line
                if line[:1] in ("[", "("):
                    hazard_lines.append((title, line[:70]))

    print("== 1. fresh extractor parse over data/raw ==")
    print(f"A (whole-line bracket)       : {stats['A']} fragments / {stats['A_tokens']} tokens")
    print(f"B (leading bracket + text)   : {stats['B']} fragments / {stats['B_tokens']} tokens")
    print(f"empty fragments skipped      : {stats['empty_fragment']}")
    print(f"A+B total relocated          : {stats['A'] + stats['B']}")
    print(f"C (bracket left in body line): {len(c_forms)} occurrences")
    def c_class(ctx):
        inner = re.search(r"\[[^\]]*\]", ctx).group(0)
        body = inner[1:-1].strip()
        if not body:
            return "empty [ ] (lacuna marker)"
        if "[" in ctx and re.search(r"[A-Za-z]\[[A-Za-z]+\]", ctx):
            return "editorial expansion W[illiam]"
        return "editorial insertion"
    from collections import Counter
    print("  C composition           :", dict(Counter(c_class(ctx) for _, ctx in c_forms)))
    for title, ctx in c_forms[:10]:
        print(f"  - {title}: ...{ctx}...")

    # ---- 2. committed text layer: rules, ASCII, token totals -------------
    files = sorted(TEXT.glob("[0-9][0-9][0-9][0-9]_*.txt"))
    print("\n== 2. committed text layer ==")
    print(f"text files                   : {len(files)}")
    non_ascii = 0
    ascii_lines = 0
    total_body_tokens = 0
    first_char_drop_lines = 0
    first_char_drop_tokens = 0
    kind_counts = {"heading": 0, "stage": 0, "speaker": 0, "body": 0}
    for path in files:
        raw = path.read_bytes()
        for b in raw:
            if b > 0x7F:
                non_ascii += 1
        for ln in raw.decode("utf-8").splitlines():
            if not ln or ln.startswith("#"):
                continue
            ascii_lines += 1
            k = kind_of(ln)
            kind_counts[k] += 1
            if k == "body":
                total_body_tokens += len(TOKEN_RE.findall(ln))
                if ln[:1] in ("[", "("):
                    first_char_drop_lines += 1
                    first_char_drop_tokens += len(TOKEN_RE.findall(ln))
    print(f"non-ASCII bytes              : {non_ascii}")
    print(f"content lines                : {ascii_lines}")
    print(f"line kinds                   : {kind_counts}")
    print(f"body tokens (regex rule)     : {total_body_tokens}")
    print(f"naive-first-char hazard      : {first_char_drop_lines} body lines / "
          f"{first_char_drop_tokens} tokens")
    print("\n  hazard body lines (first char is [ or ( but line is NOT a marker):")
    for title, line in hazard_lines[:10]:
        print(f"  - {title}: {line!r}")

    # ---- 3. the 849-token numeric closure --------------------------------
    print("\n== 3. bracket-fix token closure ==")
    print(f"committed body tokens        : {total_body_tokens}")
    print(f"B-fragment tokens            : {stats['B_tokens']}")
    print(f"body tokens if B left inline : {total_body_tokens + stats['B_tokens']}")

    # ---- 4. special cases ------------------------------------------------
    print("\n== 4. special cases ==")
    elegy = [p for p in files if "elegy" in p.read_text(encoding="utf-8").splitlines()[1].lower()]
    if elegy:
        lines = [ln for ln in elegy[0].read_text(encoding="utf-8").splitlines()
                 if ln and not ln.startswith("#")]
        print(f"elegy text file              : {elegy[0].name} / {len(lines)} lines / "
              f"{sum(len(TOKEN_RE.findall(x)) for x in lines)} tokens")
    broken = (RAW / "Poetry" / "elegy.html").read_text(encoding="latin-1")
    print(f"elegy malformed </TITLE      : {broken.count('</TITLE')} occurrence(s)")
    none_all = []
    for path in sorted(RAW.glob("**/*.html")):
        txt = path.read_text(encoding="latin-1")
        n = txt.count("<h3>None</h3>")
        if n:
            none_all.append((str(path.relative_to(RAW)), n))
    authoritative = {src_rel for _, _, _, src_rel in docs}
    none_auth = [(f, n) for f, n in none_all if f in authoritative]
    print(f"<h3>None</h3> occurrences    : total {sum(n for _, n in none_all)} in "
          f"{[f for f, _ in none_all]}")
    print(f"  in authoritative doc list  : {sum(n for _, n in none_auth)} in {none_auth}")
    print(f"  legacy mirror copies       : {sum(n for _, n in none_all) - sum(n for _, n in none_auth)}")
    print(f"  extractor counter skipped  : 1 (see extract-rerun.log)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
