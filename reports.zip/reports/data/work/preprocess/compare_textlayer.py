#!/usr/bin/env python3
"""compare_textlayer.py -- reproducibility check for the text layer.

Compares the committed data/text/ layer with a fresh re-extraction produced by
tools/extract.py (see extract-rerun.log). The manifest is compared ignoring the
`text` path column, which necessarily differs because the fresh copy lives in
reports/data/work/preprocess/text/.

Usage:
    python3 reports/data/work/preprocess/compare_textlayer.py
"""

import sys
from pathlib import Path

PROJ = Path(__file__).resolve().parents[4]
COMMITTED = PROJ / "data" / "text"
FRESH = PROJ / "reports" / "data" / "work" / "preprocess" / "text"


def main():
    names = sorted(p.name for p in COMMITTED.glob("[0-9][0-9][0-9][0-9]_*.txt"))
    different = []
    for name in names:
        if (COMMITTED / name).read_bytes() != (FRESH / name).read_bytes():
            different.append(name)
    print(f"compared text files      : {len(names)}")
    print(f"byte-different files     : {len(different)}")
    print("verdict                  : "
          + ("BYTE-IDENTICAL" if not different else f"DIFFERENT: {different[:5]}"))

    old = (PROJ / "data" / "manifest.tsv").read_text(encoding="utf-8").splitlines()
    new = (FRESH.parent / "manifest.tsv").read_text(encoding="utf-8").splitlines()

    def without_text_column(rows):
        return ["\t".join(c for i, c in enumerate(r.split("\t")) if i != 4)
                for r in rows]

    same = without_text_column(old) == without_text_column(new)
    print(f"manifest rows (ignoring text path): "
          f"{'IDENTICAL' if same else 'DIFFERENT'}")
    return 0 if not different and same else 1


if __name__ == "__main__":
    sys.exit(main())
