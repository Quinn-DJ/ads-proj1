# 验证与规模实验证据（results-verify.md）

运行日期 2026-10-20；本轮重新构建基线（`cmake -S . -B build -DCMAKE_BUILD_TYPE=Release` + 编译 + ctest 18/18）；所有数字来自本轮命令；日志在 `reports/data/logs/verify/`。

环境：Apple M3 / macOS 27.0.1（Darwin 27.0.0, arm64）/ 16 GiB RAM / `/usr/bin/c++`（Apple clang），构建类型 Release。本轮与 analyst-core 在同一台机器上并行跑测量，**所有计时都可能被并行负载抬高**；对策见各条口径说明。临时索引/语料在 `reports/data/work/verify/` 与 `/tmp`，不作为证据。

## 关键事实速查

| 编号 | 事实 | 关键数值 | 日志 |
|---|---|---|---|
| F1 | ctest 全量 | 18/18 通过，总耗时 40.90 s | `logs/verify/ctest-full.log` |
| F2 | 单元测试规模 | 8 个可执行 / 46 个 TEST_CASE / 85 155 条断言，全过 | `logs/verify/assertions.log` |
| F3 | 18 条 ctest 组成 | 8 个 Catch2 + 2 个语料冒烟 + 8 个交叉对拍 | `tests/CMakeLists.txt`、F1 日志 |
| F4 | 黄金样例（讲义四文档） | raw：4 doc / 25 token / 11 term / 750 B；过滤版：16 token / 8 term / 553 B | `logs/verify/golden4-dump.log`、`golden4-stop-dump.log` |
| F5 | 三词典产物逐字节一致 | 3 685 655 B × 3，SHA-256 全同 `267c51…6ebae` | `logs/verify/dicts-spimi.log` |
| F6 | SPIMI vs 内存构建 | 17 run / 峰值 5 129 活词；产物 `cmp` 逐字节一致 | 同上 |
| F7 | 全词表独立对拍 | 正式 14 937 词、raw 25 705 词、v2 14 937 词全项一致 | `logs/verify/brute-force.log` |
| F8 | 磁盘词典 verify-all | v1/v2 各 14 937 词 **0 差异**；114 页读 / 29 819 缓存命中 | `logs/verify/verify-all.log` |
| F9 | 短语独立对拍 | 305 采样 / 303 检查 / 0 不一致，21.20 s | `logs/verify/check-phrases.log` |
| F10 | RFC 第二语料端到端 | 3 doc / 75 250 token / 4 328 词形；推导停用词 **58**（非 56）；must/may/should 被拒 | `logs/verify/rfc-e2e.log` 等 |
| F11 | B+Tree 规模 | 10 万→5 000 万键，15.100 B/键恒定，5 000 万高 4、4 页读；4 亿外推 6.04 GB/高度 4 | `logs/verify/bptree-bench.log`、`csv/verify/bptree-bench.csv` |
| F12 | 50 万文档合成语料 | 生成 73.75 s / 50 万文件 / 2 000 万 token / 1.9 GB 磁盘 | `logs/verify/500k-generate.log` |
| F13 | 50 万文档块式构建 | 4 908 747 term / 19 999 929 posting / 427 603 247 B / 4 855 run；峰值 RSS 1.01 GiB | `logs/verify/500k-experiments.log` |
| F14 | 50 万文档压缩构建 | 284 560 009 B（v1 的 66.55%），峰值 RSS 1.46 GiB | 同上 |
| F15 | 50 万文档内存构建 | 峰值 RSS **2.00 GiB**；427 603 247 B 与块式构建**逐字节相同**（SHA-256 `4fcb45…`）；real 76.75 s | 同上 |
| F16 | 压缩 + 磁盘词典组合 | v2 1 725 694 B + sidecar 237 568 B；verify-all 0 差异 | `logs/verify/build-indexes.log`、`verify-all.log` |
| F17 | 实现规模与依赖 | 9 828 行（src 5 346 / include 1 103 / tests 1 578 / tools 1 801）；注释率核心 31.0%；`mse` 329 136 B，仅链接系统库 | `logs/verify/wc-lines.log`、`comment-ratio.log`、`otool.log` |
| F18 | 异常与口径缺口 | verify-all 需 `--dict-file`；`--pretty` 默认 manifest 坑；RFC 推导数 58 与历史文档 56 不符；src 注释率 28.1%<30% | 文末 F18 |

---

## F1 本轮 ctest 全量重跑

命令（项目根目录）：

```bash
/usr/bin/time -p ctest --test-dir build --output-on-failure
```

结果：**18/18 passed**，`Total Test time (real) = 40.90 sec`；外层计时 real 40.91 s、user 35.87 s、sys 4.28 s。原始日志 `logs/verify/ctest-full.log`。

## F2 8 个 Catch2 可执行文件 / 46 个 TEST_CASE / 85 155 条断言

逐个直接运行 `build/tests/test_*`（Catch2 v3 默认报告器末行给出 `All tests passed (N assertions in M test cases)`），完整输出 `logs/verify/assertions.log`；`grep -c 'TEST_CASE' tests/*.cpp` 合计 46（逐文件：tokenizer 2、stemmer 7、dict 6、index 8、query 7、stopwords 3、count 3、bptree 10）。

| 可执行 | 用例数 | 断言数 | 覆盖内容（由 TEST_CASE 标题与文件注释归纳） |
|---|---:|---:|---|
| `test_tokenizer` | 2 | 24 | 切词器边界（撇号/连字符/数字/大小写）+ 文档级行类型开关（heading/stage/speaker 选项） |
| `test_stemmer` | 7 | 101 | Porter step1a–5b 各步、收缩词、必须不变的护栏词 |
| `test_dict` | 6 | 50 | splay/hash/map 三实现行为脚本 + 随机负载跨实现互验 + 伸展树旋转/哈希 rehash 可观测性 |
| `test_index` | 8 | 248 | 黄金样例 posting 表、splay/hash 产物逐字节一致、停用词使位置重编号、坏文件拒绝、块式=内存、varint 各长度档、v2 往返且变小、B+Tree sidecar 全词服务 |
| `test_query` | 7 | 26 | word/phrase/boolean、四个阈值、停用词在 raw/过滤索引上的语义、词干化、`--pretty` 定位 |
| `test_stopwords` | 3 | 11 | 39 个结构词、内容/古体词保持可检索、缺文件报错 |
| `test_count` | 3 | 47 | golden4 熵特征手算、plain 格式标记形行可检索、三特征推导规则边界 |
| `test_bptree` | 10 | **84 648** | bulk-load 全键查找、逐条插入 vs `std::map` oracle、upsert、叶链范围扫描、两种构建方式等价、单键/空树不变量、输入契约、文件往返、页读计数与缓存、坏魔数拒绝 |
| **合计** | **46** | **85 155** | — |

注：断言数高度集中在 `test_bptree`（84 648，占 99.3%）；其余 7 个可执行共 507 条断言。日志 `logs/verify/assertions.log`。

## F3 18 条 ctest 的组成与各自测什么

耗时取自 F1 日志（部分为 0.00 s 因 ctest 计时精度为 10 ms）：

| # | 名称 | 耗时 | 内容 |
|---:|---|---:|---|
| 1–8 | `test_tokenizer` / `test_stemmer` / `test_dict` / `test_index` / `test_query` / `test_stopwords` / `test_count` / `test_bptree` | 0.00–0.03 s | F2 的 8 个 Catch2 单元测试可执行文件 |
| 9 | `mse_stats` | 0.07 s | 冒烟：主语料仍能加载，正则断言 `documents: 195` |
| 10 | `rfc_stats` | 0.01 s | 冒烟：第二语料 `data2/` 零代码改动加载，断言 `documents: 3` |
| 11 | `crosscheck_build` | 0.23 s | 用 `mse build --stop-words --stem` 生成对拍用 v1 索引 + sidecar（ctest fixture） |
| 12 | `crosscheck_brute_force` | 1.19 s | Python 独立扫描语料 + 独立解析索引，全词表比较 df/tf/docID/positions（v1） |
| 13 | `crosscheck_phrases` | 19.48 s | 300 条随机短语：Python 在规范化 token 流上暴力扫描 vs `mse query --phrase`（v1） |
| 14 | `crosscheck_dictfile` | 0.05 s | B+Tree sidecar 全词表解析 vs 全量加载，正则断言 `0 mismatches`（v1） |
| 15 | `crosscheck_compress_build` | 0.24 s | 生成 v2（gap+varint）索引 + sidecar |
| 16 | `crosscheck_compress` | 1.30 s | 用同一 `brute_force.py` 独立解析 v2 文件并比较（脚本自动识别版本字段） |
| 17 | `crosscheck_compress_dictfile` | 0.04 s | v2 索引 + sidecar 的 verify-all，断言 `0 mismatches` |
| 18 | `crosscheck_compress_phrases` | 18.21 s | 在 v2 索引上重复短语扫描对拍 |
| 合计 | — | 40.90 s | 18/18 |

交叉对拍全部由 Python 独立实现（`tools/brute_force.py` 自己切词/解析文件、`tools/check_phrases.py` 自己扫 token 流），因此是"实现互验"而非同一实现自证。定义见 `tests/CMakeLists.txt`。

## F4 黄金样例：讲义四文档示例（期望 vs 实际）

fixture：`tests/fixtures/golden4/data/manifest.tsv` + 4 篇文本（Doc 1–4），句子逐字取自讲义 §1.2。命令：

```bash
./build/mse build --manifest tests/fixtures/golden4/data/manifest.tsv \
    --index reports/data/work/verify/golden4/raw.bin
./build/mse dump  --index reports/data/work/verify/golden4/raw.bin --term <term>
```

raw 构建摘要（`logs/verify/golden4-dump.log`）：`documents 4 / tokens 25 / terms 11 / postings 24 / positions 25 / index 750 B / invariants OK`；四个句子长度 3+7+8+7=25。实际 posting 表（docID, tf, positions）如下，**与 `tests/test_index.cpp` 的期望表（行 131–141，断言 248 条的一部分）逐项一致，测试通过**：

| term | postings (doc, tf, positions) |
|---|---|
| a | (2,1,{5}), (3,1,{5}), (4,1,{5}) |
| arrived | (3,1,{3}), (4,1,{3}) |
| damaged | (2,1,{3}) |
| delivery | (3,1,{0}) |
| fire | (2,1,{6}) |
| gold | (1,1,{0}), (2,1,{2}), (4,1,{2}) |
| in | (2,1,{4}), (3,1,{4}), (4,1,{4}) |
| of | (2,1,{1}), (3,1,{1}), (4,1,{1}) |
| shipment | (2,1,{0}), (4,1,{0}) |
| silver | (1,1,{1}), (3,2,{2,6}) |
| truck | (1,1,{2}), (3,1,{7}), (4,1,{6}) |

**讲义不自洽（"a" 一行）**：讲师矩阵把 `a` 记为 (2,1)(4,1)（times=2），但示例句子 doc3 是 "Delivery of silver arrived in **a** silver truck"——按句子应为 (2,1)(3,1)(4,1)（times=3）。`tests/test_index.cpp` 行 125–130 有显式注释记录这处差异（并注明原版 .ppt 字节流逐字确认过句子含 "a"）；fixture 使用讲义**原句**，测试期望以句子为准。`notes.md` §3.8 同记录。除此之外其余 10 个词与讲义表格一致。

**去停用词版（`--stop-words data/stopwords.txt`，不词干化）**：`tokens 16 / terms 8 / postings 15 / index 553 B`；`a/in/of` 不在词表（`term not found`），位置在过滤后 token 流上重编号（`logs/verify/golden4-stop-dump.log`）：

| term | postings (doc, tf, positions) |
|---|---|
| arrived | (3,1,{2}), (4,1,{2}) |
| damaged | (2,1,{2}) |
| delivery | (3,1,{0}) |
| fire | (2,1,{3}) |
| gold | (1,1,{0}), (2,1,{1}), (4,1,{1}) |
| shipment | (2,1,{0}), (4,1,{0}) |
| silver | (1,1,{1}), (3,2,{1,3}) |
| truck | (1,1,{2}), (3,1,{4}), (4,1,{3}) |

该结果与 `test_index.cpp` 行 190–200 的期望一致（doc3 中 silver 由 (2,6) 变为 (1,3)）。期望值来源说明：Catch2 的 `-s` 只展开表达式、不打印容器内容，因此改用 CLI `mse dump` 读取同一 fixture 的实际索引做对照；两条路径（测试内 `buildIndex` 与 CLI `mse build`）都走同一构建管线，且测试本身断言通过。

## F5 三词典（splay / hash / map）产物逐字节一致

命令：`mse build --stop-words data/stopwords.txt --stem --dict {splay,hash,map} --index work/verify/dict-*.bin`（`logs/verify/dicts-spimi.log`）。三个索引文件均为 **3 685 655 B**，`cmp` 两两一致，SHA-256 同为 `267c51a217b40771505fa4fd25314015fbd6e6c5e9fb58ab4b78106d7ae6ebae`。构建期计数（同一日志，仅供佐证，完整三列性能对比归 T1）：splay comparisons 6 392 724 / rotations 5 850 795；hash comparisons 688 494 / rehashes 11；map comparisons 9 435 694；构建耗时 0.20 / 0.10 / 0.13 s（并行负载下，仅作数量级参考）。词典是纯实现细节，输出与结构无关。

## F6 SPIMI 块式构建 vs 内存构建逐字节一致

`mse build-blocks --stop-words data/stopwords.txt --stem --block-terms 4096 --index work/verify/spimi.bin`：

- blocks **17**（预算 4096 term，峰值 **5 129** 活词）
- run bytes 4 166 556（临时文件，用后删除）
- scan 0.11 s + merge 0.03 s
- 产物 3 685 655 B，`invariants: OK`；与 `mse build` 产物 `cmp` **逐字节一致**，SHA-256 同为 `267c51…`。

日志 `logs/verify/dicts-spimi.log`。

## F7 独立实现全词表对拍（brute_force.py）

脚本自行切词、加载参考 Porter（NLTK `MARTIN_EXTENSIONS` 行为）、并**独立解析索引文件**（v1/v2 都支持），逐词比较 df、tf、每个 posting 的 docID/tf/positions。三次运行全部 `result: OK`（`logs/verify/brute-force.log`）：

| 索引 | 配置 | 规模 | 结论 |
|---|---|---|---|
| `formal-v1.bin` | `--stop-words --stem` | 195 doc / 14 937 term / 556 866 token | 14 937 词全项一致 |
| `raw-v1.bin` | 无停用词、无词干 | 195 doc / 25 705 term / 866 626 token | 25 705 词全项一致 |
| `formal-v2.bin` | `--stop-words --stem --compress` | 195 doc / 14 937 term / 556 866 token | 14 937 词全项一致 |

脚本**没有** `--dict-file` 参数（只接受 `--manifest/--index/--stop-words/--stem`），磁盘词典路径由 F8 的 verify-all 覆盖。

## F8 磁盘 B+Tree 词典 `dump --verify-all`

`logs/verify/verify-all.log`：

| 索引 + sidecar | verified terms | mismatches | dict reads |
|---|---:|---:|---|
| v1 `formal-v1.bin` + `formal-v1.bpt` | 14 937 | **0** | 114 page reads / 29 819 cache hits |
| v2 `formal-v2.bin` + `formal-v2.bpt` | 14 937 | **0** | 114 page reads / 29 819 cache hits |

冷查询示例 `banquo`（df=1, tf=27, doc 33 "Macbeth"）：v1 词典 2 页读 + 索引读 8 308 B（全量 3 685 655 B 的 **0.23%**）；v2 索引读 8 238 B（全量 1 725 694 B 的 **0.48%**）。两版本 positional 输出一致（v2 仅 postings 编码不同）。

## F9 短语查询独立对拍（check_phrases.py）

`python3 tools/check_phrases.py --index formal-v1.bin --stop-words data/stopwords.txt --stem --queries 300`：采样 305 条短语，**303 条被检查、2 条跳过**（含全停用词等退化情形），0 不一致；real **21.20 s**（user 17.84 / sys 2.54）。脚本对每条短语在 Python 侧重建规范化 token 流并做连续子串扫描，再与 `mse query --phrase --json` 的文档集合比较。日志 `logs/verify/check-phrases.log`。

## F10 RFC 第二语料端到端（`data2/`：RFC 1035 / 5321 / 7231，plain 格式）

**语料统计**（`mse stats --manifest data2/data/manifest.tsv`，`logs/verify/rfc-e2e.log`）：3 文档、9 946 行（全部 body）、81 848 words、569 472 bytes、category 只有 IETF。

**词频**（`mse count` raw，输出 `work/verify/rfc-count.csv`）：tokens **75 250**、distinct **4 328**、hapax **1 506**（tf=1）、stop-candidates（df_ratio≥0.75 且 tf_share≥0.1%）**127**。与 `tools/check_wordcount.py --manifest data2/data/manifest.tsv` 的输出 **逐字节一致**（含 entropy/entropy_norm/entropy_rate_norm 三列）。

**熵驱动的停用词推导**：`mse stopwords --derive --manifest data2/data/manifest.tsv --min-df-ratio 0.4 --min-entropy-rate 0.93 --out work/verify/rfc-stopwords.txt --compare data/stopwords.txt`，本轮实测 **58 词**（历史 README/notes 记 56，属过期历史值，本轮以 58 为准，见 F18）。完整列表（按 tf 降序）：

```text
the a to of and in is that for be rfc or not server as this are an by it with if
data from page information on used when any standards use can other one e will
some have all protocol no only case its more list error time received each does
same they g transfer however multiple
```

与莎士比亚静态 39 词表（`data/stopwords.txt`）比较：39 词中 **38** 个出现在 RFC 词表里（`my` 不在 RFC 词表），重叠 **26**；只在静态表、不在推导表 **12**：`but do his i me so than their then what which yet`；只在推导表 **32**：`an any can case data does e each error g however information its list multiple one only other page protocol received rfc same server some standards they time transfer use used will`。其中 `e`、`g` 来自 `e.g.` 这类缩写的切词残余，属可解释的语料级现象。

**为什么 `must/may/should` 没被判停用词**（CSV 实测列，停用词的判据是"宽∧重∧平"：df_ratio≥0.4、tf_share≥0.001、entropy_rate_norm≥0.93）：

| term | tf | df | df_ratio | tf_share | stop_candidate（两特征） | entropy | entropy_norm | entropy_rate_norm | 三特征判定 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---|
| must | 322 | 3 | 1.000 | 0.004279 | 1 | 1.120873 | 0.707192 | **0.809410** | 否（不够"平"） |
| may | 297 | 3 | 1.000 | 0.003947 | 1 | 1.287917 | 0.812585 | **0.898721** | 否（不够"平"） |
| should | 341 | 3 | 1.000 | 0.004532 | 1 | 1.393546 | 0.879229 | **0.884891** | 否（不够"平"） |
| page | 254 | 3 | 1.000 | 0.003375 | 1 | 1.536099 | 0.969170 | 0.997273 | **是** |
| rfc | 784 | 3 | 1.000 | 0.010419 | 1 | 1.470054 | 0.927501 | 0.987599 | **是** |
| server | 557 | 3 | 1.000 | 0.007402 | 1 | 1.518319 | 0.957953 | 0.993316 | **是** |
| error | 108 | 3 | 1.000 | 0.001435 | 1 | 1.438002 | 0.907278 | 0.977924 | **是** |
| request | 470 | 3 | 1.000 | 0.006246 | 1 | 0.516856 | 0.326100 | **0.446650** | 否（集中） |
| mail | 476 | 3 | 1.000 | 0.006326 | 1 | 0.648300 | 0.409032 | **0.548308** | 否（集中） |

解释：`must/may/should` 的 df_ratio 都是 1.0（三篇 RFC 全覆盖，两特征规则会收），但速率分布倾斜（7231 满篇 MUST、1035 少用），`entropy_rate_norm` 只有 0.81/0.90/0.88，低于 0.93 被拒；`page/rfc/server/error` 则接近 0.98–0.997 被收。`request/mail` 甚至只有 0.45/0.55：高度集中在 SMTP 文档里，也被拒。这说明"平"这一维在跨语料场景真实起作用，也说明不存在万能停用词表（同语料上莎士比亚推导出 39 词、RFC 推导出 58 词，重叠仅 26）。

**建索引**（plain 格式，`logs/verify/rfc-build-query.log`）：

| 配置 | tokens | terms | postings | positions | 索引字节 | 耗时 |
|---|---:|---:|---:|---:|---:|---:|
| raw（无过滤/无词干） | 75 250 | 4 328 | 7 006 | 75 250 | 510 181 | 0.02 s |
| 正式（推导 58 停用词 + `--stem`） | 45 370 | 2 660 | 4 594 | 45 370 | 308 164 | 0.01 s |

**查询示例**（正式索引，flags 自动为 stopwords+stemmed）：`--word zone` → 3 篇全命中；`--word postmaster` → 1 篇（doc 2 rfc5321），规范化后 `terms: postmast`，`--pretty` 定位到源行 `o The reserved mailbox name "postmaster" may be used in a RCPT`（需同时传 `--manifest data2/data/manifest.tsv`，否则落到默认莎士比亚 manifest，见 F18）；`--words "name server" --min-match 2` → `server` 被判停用词并给出 note，实际只剩 `name`，返回 3 篇——跨语料停用词差异在查询侧可见。`--pretty` 修复前后的对照日志：`rfc-build-query.log`（错误 manifest）与 `rfc-pretty.log`（显式 manifest）。

**全词表对拍**：`brute_force.py --manifest data2/data/manifest.tsv`，raw 索引 4 328 词全项一致；正式索引 2 660 词全项一致（exit 0，`rfc-build-query.log`）。

## F11 B+Tree 规模实测（Bonus：4 亿词词典外推）

命令（`logs/verify/bptree-bench.log`，CSV 由 `work/verify/parse_bptree.py` 生成到 `csv/verify/bptree-bench.csv`）：`./build/mse bptree-bench --keys N --lookups 1000`（4KB 页）。100 万/10 万/1000 万键各跑 3 次取中位数；3000 万/5000 万太贵只跑 1 次（并行负载下计时偏保守）。

| keys | height | pages（叶页数） | file_bytes | bytes/key | lookups | page_reads/查询 | seconds（口径） |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 100 000 | 2 | 369 (368) | 1 515 520 | 15.1552 | 1 000 | 2.00 | 0.020（3 次中位：0.02/0.02/0.02） |
| 1 000 000 | 3 | 3 688 (3 677) | 15 110 144 | 15.1101 | 1 000 | 3.00 | 0.180（3 次：0.18/0.18/0.18） |
| 10 000 000 | 3 | 36 865 (36 765) | 151 003 136 | 15.1003 | 1 000 | 3.00 | 1.700（3 次：1.80/1.65/1.70） |
| 30 000 000 | 3 | 110 593 (110 295) | 452 993 024 | 15.0998 | 1 000 | 3.00 | 6.370（单次，build 5.92 s） |
| 50 000 000 | 4 | 184 322 (183 824) | 754 987 008 | 15.0997 | 1 000 | **4.00** | 13.000（单次，build 11.82 s） |

每次查询 `1000 verified`（值全部校验）。输出没有直接打印"叶容量/扇出"，由页数与高度反推：每叶约 **272 键**（100 000/368=271.7；50 000 000/183 824=272.1），内部页扇出约 **330–370**（由内部页数/叶页数反推）；页填充实测 min 2 057–2 887 B、max 4 087–4 092 B（预算 4 096 B）；随机查询恒等于树高页读，说明"缓存=1 页"的计数正确（每层 1 页、无重复读）。

**4 亿键外推**（用实测 15.0997 B/键与 272 键/叶、扇出≈370，同一套公式在 10 万–5 000 万五档上逐点吻合）：文件 ≈ **6.04 GB**（5.63 GiB），叶 ≈1 470 588 页，总页数 ≈1 474 574；**高度 4**（5 000 万键时已实测为 4，4 层容量约 1.4×10¹⁰ 键，4 亿仍在 4 层内）→ 单次查询 **4 页 = 16 KB**。即词典无法常驻内存（≈6 GB）时点查仍然廉价。

## F12 50 万文档合成语料（Bonus：50 万文件侧）

精确生成命令与日志 `logs/verify/500k-generate.log`：

```bash
python3 tools/gen_synthetic_corpus.py --root /tmp/mse-scale-corpus-500k \
    --docs 500000 --tokens-per-doc 40 --vocab 5000000
```

输出：documents **500 000**、tokens **20 000 000**、vocab cap 5 000 000、text bytes **180 000 000**、generate **73.67 s**（外层计时 real 73.75 s / user 17.92 / sys 29.16）。产物：500 000 个文本文件、manifest 36 277 839 B；`du -sh` 磁盘占用 **1.9 GB**（每篇约 360 B 文本因 APFS 4 KB 块分配放大到约 3.9 KB，即 50 万小文件的元数据/分配开销本身是规模成本的一部分）。语料生成后用于 F13–F15，证据采集完成后已删除（见 F18）。

`mse stats --manifest /tmp/mse-scale-corpus-500k/data/manifest.tsv`（同一日志）：documents 500 000、lines 500 000（body 500 000）、**words 20 000 000**、bytes 179 500 000；real **31.84 s**，**max RSS 486 408 192 B = 463.9 MiB**（读 50 万个小文件的 I/O 与 doc 表是主要成本）。

## F13 50 万文档块式构建（v1）

命令（`/usr/bin/time -l` 计峰值 RSS，`logs/verify/500k-experiments.log`）：

```bash
/usr/bin/time -l ./build/mse build-blocks \
    --manifest /tmp/mse-scale-corpus-500k/data/manifest.tsv \
    --block-terms 4096 --index reports/data/work/verify/scale-500k-v1.bin
```

| 指标 | 值 |
|---|---|
| documents / tokens | 500 000 / 20 000 000 |
| blocks（budget 4096） | **4 855** |
| 峰值活词 | **4 120** |
| run 临时字节（用后删除） | 559 888 708 |
| scan time / merge time | **5.47 s / 125.08 s** |
| terms | **4 908 747** |
| index bytes | **427 603 247**（v1） |
| invariants | OK |
| 总 real（含 I/O） | **168.16 s**（user 130.26 / sys 18.99） |
| **峰值 RSS** | **1 084 784 640 B = 1 034.5 MiB ≈ 1.01 GiB**（macOS `peak memory footprint` 1 801 078 488 B ≈ 1.68 GiB） |

postings 数：`build-blocks` 输出不打印 posting 总数，用 `work/verify/parse_index_info.py` 独立解析冻结索引的词表得 **19 999 929** postings、20 000 000 positions（= tokens，闭合）。另：扫描 5.47 s 说明 50 万小文件读入本身不是瓶颈（F12 stats 的 31.84 s 含更重的文档/词聚合），**merge 125 s 才是块式构建的主要成本**（4 855 路归并 4.9 M 词）。

## F14 50 万文档压缩构建（v2）

同 F13 命令加 `--compress`：

| 指标 | v1（F13） | v2（--compress） |
|---|---:|---:|
| blocks / 峰值活词 | 4 855 / 4 120 | 4 855 / 4 120 |
| scan / merge | 5.47 / 125.08 s | 5.42 / 123.31 s |
| terms | 4 908 747 | 4 908 747 |
| index bytes | 427 603 247 | **284 560 009（66.55%，省 33.45%）** |
| 总 real | 168.16 s | 162.29 s |
| **峰值 RSS** | 1 084 784 640 B（1.01 GiB） | **1 566 867 456 B（1.46 GiB）**（footprint 1 697 482 456 B ≈ 1.58 GiB） |

压缩收益 33.45% 低于莎士比亚语料的 53.18%（F16）——合成语料 tf=1、位置差分为 1，varint 省的是固定 4 字节字段，收益主要来自 docID/位置的 1 字节编码；真实语料 posting 更长、重复更多。v2 峰值 RSS 反而更高（约 +45%），说明压缩期额外持有未压缩 postings + 变长缓冲两份数据，是"时间换空间"的代价。

## F15 50 万文档内存构建（`mse build`）与块式构建对比

命令：`/usr/bin/time -l ./build/mse build --manifest /tmp/mse-scale-corpus-500k/data/manifest.tsv --index .../scale-500k-mem.bin`。

| 指标 | 内存构建 `mse build` | 块式构建 `build-blocks`（F13） |
|---|---:|---:|
| documents / tokens | 500 000 / 20 000 000 | 500 000 / 20 000 000 |
| terms / postings / positions | 4 908 747 / 19 999 929 / 20 000 000 | 同左（独立解析核对） |
| 索引字节 | 427 603 247 | 427 603 247 |
| 构建内部计时 | **44.93 s** | scan 5.47 + merge 125.08 s |
| 总 real（含读 50 万文件） | **76.75 s**（user 47.18 / sys 15.62） | **168.16 s**（user 130.26 / sys 18.99） |
| **峰值 RSS** | **2 152 579 072 B = 2.00 GiB**（footprint 2 150 025 184 B） | **1 084 784 640 B = 1.01 GiB** |
| 产物一致性 | — | 与内存构建产物 `cmp` **逐字节一致**，SHA-256 同为 `4fcb4537d3b220cdf0ed7cf25840540e576c42f209915f46d1d894bc2151e1e8` |

内存构建的词典计数：splay comparisons **593 365 175**、rotations 578 273 922（4.9 M 词表 + 2 000 万 token 访问；作为"内存词典规模"的代价对照）。结论：50 万文档 / 2 000 万 token 在这台 16 GiB 机器上两种构建都跑通；**块式构建用约 2.2 倍的墙钟换来峰值内存减半**（1.01 GiB vs 2.00 GiB），且产物逐字节相同——这是"内存 O(预算) 与词表规模无关"在 50 万文件规模上的直接证据。

## F16 压缩 + 磁盘词典组合（正式配置 `--compress --dict-file`）

`mse build --stop-words data/stopwords.txt --stem --compress --dict-file work/verify/formal-v2.bpt --index work/verify/formal-v2.bin`（`logs/verify/build-indexes.log`）：v1 3 685 655 B → v2 **1 725 694 B（46.82%，省 53.18%）**，sidecar **237 568 B**（= v2 索引的 13.77%；v1 口径下为 6.44%）。`dump --verify-all --index formal-v2.bin --dict-file formal-v2.bpt` → verified **14 937 terms / 0 mismatches**，114 page reads / 29 819 cache hits（F8）。压缩与磁盘词典正交可叠加。

## F17 实现规模与依赖

行数（`wc -l`，`logs/verify/wc-lines.log`）：`src/*.cpp` 12 文件 **5 346** 行、`include/*.hpp` 11 文件 **1 103** 行、`tests/*.cpp` 8 文件 **1 578** 行、`tools/*.py` 9 文件 **1 801** 行，合计 **9 828** 行。

注释率（脚本 `work/verify/comment_ratio.py`，方法：逐字符状态机识别 `//`、`/* */` 与字符串/字符字面量，按"纯注释行 / 非空行"统计；字符串里的 `http://` 等不计为注释）——`logs/verify/comment-ratio.log`：

| 范围 | 文件数 | 非空行 | 纯注释行 | 行内注释 | 代码行 | 注释率 |
|---|---:|---:|---:|---:|---:|---:|
| `src/*.cpp` | 12 | 4 986 | 1 403 | 123 | 3 460 | **28.1%** |
| `include/*.hpp` | 11 | 925 | 428 | 110 | 387 | **46.3%** |
| C++ 核心（src+include） | 23 | 5 911 | 1 831 | 233 | 3 847 | **31.0%** |
| `tests/*.cpp` | 8 | 1 388 | 244 | 66 | 1 078 | 17.6% |

即：头文件注释充分，`src/*.cpp` 单独看只有 28.1%（低于课程 30% 目标），与头文件合并计 31.0%（≥30%）；把行内注释也算作注释行则为 (1831+233)/5911 = 34.9%。报告若引用"注释率 ≥30%"，应写口径与范围（本轮证据在 F18 注明）。

二进制与依赖：`ls -l build/mse` → **329 136 B**；`otool -L build/mse` → 仅 `/usr/lib/libc++.1.dylib`、`/usr/lib/libSystem.B.dylib`（系统库，证明纯标准库）；`otool -L build/tests/test_index` 与 `test_bptree` 同样只有系统动态库——Catch2 以静态库 `build/tests/libcatch2.a`（1 246 448 B）链接进测试可执行文件，是**测试期**依赖，`mse` 本体不链接它。`build/CMakeCache.txt`：`CMAKE_BUILD_TYPE=Release`、`CMAKE_CXX_COMPILER=/usr/bin/c++`。日志 `logs/verify/otool.log`、`env.log`。

## F18 异常、口径说明与数据缺口

1. **`--verify-all` 只在 `--dict-file` 路径实现**：不带 sidecar 运行 `mse dump --index formal-v1.bin --verify-all` 直接报 `error: dump needs --term <word>`（内存词表路径没有全词表双路径比对的语义）。因此 v1/v2 的 verify-all 都带 `--dict-file` 跑（F8）。
2. **`query --pretty` 默认 manifest 是莎士比亚**：在 RFC 索引上用 `--pretty` 时若只传 `--index`，程序会给出 `warning: --pretty positions need --stop-words matching the build` 并从 `data/manifest.tsv` 取文本，打印出错误的源行（RFC doc 2 显示成莎士比亚句子）。显式传 `--manifest data2/data/manifest.tsv --stop-words <推导表>` 后输出正确（`rfc-pretty.log`）。这是使用口径坑，不改变索引数据。
3. **RFC 推导停用词本轮是 58 词，不是历史文档的 56**：README.md/notes.md §3.12 写 56（开发期口径），本轮命令 `--min-df-ratio 0.4 --min-entropy-rate 0.93` 实测 58 词（F10）。报告只能用 **58** 与 F10 的完整列表；切词管线的变化（如 `e.g.` 的 `e`/`g` 残余）是可解释候选。同样，notes 里"RFC 建索引 2 695 词"等历史数字本轮不复现（本轮 raw 4 328 / 正式 2 660 term，F10），报告不得引用历史值。
4. **`brute_force.py` 无 `--dict-file` 选项**：磁盘词典正确性由 `dump --verify-all`（ctest 已固化为 `crosscheck_dictfile` / `crosscheck_compress_dictfile`）覆盖，二者验证范围等价（全词表 df/tf/docID/positions）。
5. **`build-blocks` 输出不打印 postings 数**：F13 的 postings 19 999 929 来自独立解析冻结文件（`work/verify/parse_index_info.py`，按 v1/v2 共用的头+文档表+词表布局求和 df/tf），与内存构建输出交叉核对见 F15。
6. **注释率口径**：`src/*.cpp` 28.1%、核心合计 31.0%（F17）。课设要求 ≥30%，报告写"核心 31.0%"时必须带范围与口径；单看 src 不达标，属真实缺口。
7. **计时受并行负载影响**：本轮与 analyst-core 同机并行，bptree、500k 构建的墙钟可能偏高；bptree 10 万/100 万/1 000 万键用 3 次中位数，3 000 万/5 000 万键单次（代价高），500k 的 stats/块构建/压缩/内存构建各单次。结构性数字（字节数、页数、高度、SHA、比较结果）是确定性的，不受负载影响。
8. **语料清理（已执行）**：500k 合成语料位于 `/tmp/mse-scale-corpus-500k`（1.9 GB，50 万小文件），证据采集完后执行 `rm -rf /tmp/mse-scale-corpus-500k` 删除（已确认目录不存在）；`work/verify/` 下的 500k 临时索引（427 603 247×2 + 284 560 009 B ≈ 1.1 GB）在记录完 F13–F15 数字与 `cmp` 结论后删除（目录由 1.1 GB 降至 26 MB）；bptree-bench 的 `.bpt` 文件由脚本用后自删。日志/CSV/本文件保留，精确复现命令见 F12/F13。
