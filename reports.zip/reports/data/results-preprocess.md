# 预处理事实复核（Lead 补充证据，2026-10-20 本轮重建后）

`results-tasks.md` 的 F1–F42 覆盖任务 1–3 的测量，但没有覆盖第 2 章 §2.2 需要的预处理细节
（方括号舞台提示、行标记规则、ASCII 前提、两处源文件特例）。本文件由 Lead 在本轮重新构建后
单独复核，供 `reports/sections/02-design.tex` 引用；命令可在 `proj1/` 根目录重跑。

证据位置：
- 日志：`reports/data/logs/preprocess/`（`extract-rerun.log`、`textlayer-repro.log`、`analyze-preprocess.log`）
- 脚本：`reports/data/work/preprocess/analyze_preprocess.py`、`compare_textlayer.py`
- 本轮重抽取的文本层：`reports/data/work/preprocess/text/`（195 个 .txt，不覆盖 `data/text/`）

---

## P1 文本层可复现（重新抽取与已提交层逐字节一致）

命令：
```bash
python3 tools/extract.py \
  --raw  /Users/quinn/Coding/ADS/proj1/data/raw \
  --text /Users/quinn/Coding/ADS/proj1/reports/data/work/preprocess/text \
  --manifest /Users/quinn/Coding/ADS/proj1/reports/data/work/preprocess/manifest.tsv
```
输出（`logs/preprocess/extract-rerun.log`）：`docs: 195 (play=37, poem=4, sonnet=154)`、
`lines: 152632 words: 930911`、`bracket stage fragments relocated from verse: 610`、
`source-generator artifacts skipped: 1`、`no extraction warnings`。

复核命令：`python3 reports/data/work/preprocess/compare_textlayer.py`
（日志 `logs/preprocess/textlayer-repro.log`）：

| 检查 | 结果 |
|---|---|
| 与 `data/text/` 比较的 .txt 文件数 | 195 |
| 逐字节不同的文件数 | **0**（BYTE-IDENTICAL） |
| manifest（忽略 text 路径列） | **IDENTICAL** |

结论：文本层是确定性产物；本轮重跑的抽取结果与仓库提交的文本层完全一致。

## P2 行类型、ASCII 前提与正文 token

由 `analyze_preprocess.py` 直接解析已提交的 `data/text/`（日志 `logs/preprocess/analyze-preprocess.log`）：

| 指标 | 值 |
|---|---|
| 文本文件数 | 195（152,632 个内容行） |
| 行类型 | heading 1,099 / stage 6,251 / speaker 30,967 / body 114,315 |
| 非 ASCII 字节数（全 195 文件） | **0** |
| 正文 token（按 tokenizer 的字母+内部撇号边界重算） | **866,626** |

说明：866,626 与 `mse count` / `tokenize --all` 的正文 token 总数一致，证明"按字节切词、
不做 Unicode 归一化"的前提在本语料上成立（换语料需重查）。

## P3 方括号舞台提示 610 处的构成

Moby 版把内嵌舞台提示写成方括号。新鲜解析的分类结果（`analyze_preprocess.py` 输出）：

| 类别 | 形态 | 数量 | 片段内 token 数 |
|---|---|---|---|
| A | 整行只有一个方括号（如 `[Sings]`） | 57 | 122 |
| B | 行首方括号片段 + 后面还有台词（如 `[To HELENA] The best wishes...`） | 553 | 849 |
| — | A+B 合计 = 重定位的舞台片段 | **610** | 971 |
| — | 空片段（`[ ]` 类，重定位时丢弃） | 1 | — |
| C | 行中间/句中保留在正文里的方括号 | **8** | —（作为正文保留） |

C 类 8 处的构成：4 处缺文标记 `[ ]`（All's Well、Midsummer、Twelfth Night、Hamlet），
2 处编者补字（Coriolanus 的 `[Censorinus,]`、`[by the people chosen]`），
2 处题名缩写展开（Elegy 的 `W[illiam]`、`S[hakespeare]`）。

A 类与 B 类被重定位为独立舞台行 `(...)`，默认不参与建索引；C 类保持在正文中（保持可检索）。

## P4 数字闭环：866,626 + 849 = 867,475

| 量 | 值 | 说明 |
|---|---|---|
| 当前正文 token | 866,626 | 本轮 `mse count` 默认配置 |
| B 类片段 token | 849 | P3 实测 |
| 若 B 类仍混在正文中 | **867,475** | 866,626 + 849，与开发期修复前的正文 token 数完全吻合 |

即：把 553 处行首方括号片段移出正文，正好减少 849 个正文 token；A 类 122 个 token
在旧版被当作标题行排除，本来就不在正文计数内，因此净变化为 849——这是"修复量 = 统计差"
的闭环证据。

## P5 行标记"首尾同时匹配"规则的实测意义

`src/corpus.cpp` 的判定规格（与 `data/text/README.md` 一致）：

| 行类型 | 判定 |
|---|---|
| heading | 行首 `[` **且** 行尾 `]` |
| stage | 行首 `(` **且** 行尾 `)` |
| speaker | 行首 `@` |
| body | 其余所有行 |

如果只看行首字符（`[`/`(`/`@` 即排除），在当前文本层上会误删 **5 行正文、37 个 token**
（`analyze_preprocess.py` 的 "naive-first-char hazard"）：全部是 elegy 的跨行括号诗句，例如
`(If there can be minority of love`、`(Fair lovely branch too soon cut off) to thee,`。
另外 C 类的 `[ ]` 缺文标记行（行首 `[` 但行尾不是 `]`）也只有"首尾同时匹配"才能留在正文里。
这解释了为什么文本层规格必须写成"首尾同时匹配"，对拍脚本也必须使用同一规格。

## P6 两处源文件特例（本轮复核）

| 特例 | 复核结果 | 说明 |
|---|---|---|
| `Poetry/elegy.html` 的残缺标签 `</TITLE`（缺 `>`） | 出现 1 次 | 解析器以 `<body>` 作为 head 结束的兜底信号；本轮重抽取该文档仍得到 584 行 / 4,501 个正文 token（`0195_funeral_elegy_by_w_s.txt`），无警告 |
| 转换残渣 `<h3>None</h3>` | 原始镜像中共 2 处：`2henryiv/full.html`（权威清单内）与 `History/2kinghenryiv/full.html`（旧版残留目录，不参与建索引） | 权威清单内 1 处；extractor 计数 `source-generator artifacts skipped: 1`，丢弃而不臆造 `ACT I` |

---

*由 Lead 于 2026-10-20 本轮重新构建后生成。引用格式：`% src: P1` … `% src: P6`。*
